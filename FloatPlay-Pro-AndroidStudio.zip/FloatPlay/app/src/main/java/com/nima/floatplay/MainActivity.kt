package com.nima.floatplay

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FloatPlayApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FloatPlayApp() {
    val context = LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("هنوز فایلی انتخاب نشده") }
    var permissionGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var showHelp by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedUri = uri
            selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "فایل انتخاب‌شده"
        }
    }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val darkTheme = isSystemInDarkTheme()
    val appColors = when {
        Build.VERSION.SDK_INT >= 31 && darkTheme -> dynamicDarkColorScheme(context)
        Build.VERSION.SDK_INT >= 31 -> dynamicLightColorScheme(context)
        darkTheme -> darkColorScheme(primary = Color(0xFFD0BCFF), surface = Color(0xFF211F26))
        else -> lightColorScheme(
            primary = Color(0xFF6750A4), onPrimary = Color.White,
            primaryContainer = Color(0xFFEADDFF), onPrimaryContainer = Color(0xFF21005D),
            secondary = Color(0xFF625B71), surface = Color(0xFFFFF8FF),
            background = Color(0xFFF7F2FA)
        )
    }
    MaterialTheme(colorScheme = appColors) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background,
            topBar = { TopAppBar(title = { Text("FloatPlay", fontWeight = FontWeight.Bold) }) }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(28.dp)) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.PictureInPictureAlt, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(42.dp))
                        Text("رسانه همیشه در دسترس", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("ویدئو یا موسیقی را در پنجره‌ای شناور روی برنامه‌های دیگر پخش کن.", color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
                Text("انتخاب رسانه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                OutlinedCard(onClick = { picker.launch(arrayOf("audio/*", "video/*")) }, shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Icon(Icons.Default.FolderOpen, null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text("انتخاب فایل صوتی یا تصویری", fontWeight = FontWeight.SemiBold)
                            Text(selectedName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                        Icon(Icons.Default.AudioFile, null)
                        Icon(Icons.Default.VideoFile, null)
                    }
                }
                if (!permissionGranted) {
                    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("برای نمایش پنجره روی برنامه‌های دیگر، این مجوز لازم است.")
                            Button(onClick = { context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) }) { Text("فعال‌سازی مجوز شناور") }
                        }
                    }
                }
                Button(
                    onClick = {
                        permissionGranted = Settings.canDrawOverlays(context)
                        val canOverlayNow = Settings.canDrawOverlays(context)
                        permissionGranted = canOverlayNow
                        if (!canOverlayNow) {
                            context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                        } else if (selectedUri != null) {
                            if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                            val intent = Intent(context, FloatingPlayerService::class.java).apply { action = FloatingPlayerService.ACTION_PLAY; data = selectedUri }
                            ContextCompat.startForegroundService(context, intent)
                        }
                    }, enabled = selectedUri != null || !permissionGranted,
                    modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp)
                ) { Icon(Icons.Default.PictureInPictureAlt, null); Spacer(Modifier.width(8.dp)); Text(if (!permissionGranted) "اعطای مجوز و ادامه" else "پخش در پنجره شناور") }
                TextButton(onClick = { showHelp = true }) { Text("راهنمای کنترل پنجره") }
                Spacer(Modifier.weight(1f))
                Text("FloatPlay Pro • نسخه 1.1.0", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
        if (showHelp) AlertDialog(onDismissRequest = { showHelp = false }, confirmButton = { TextButton(onClick = { showHelp = false }) { Text("متوجه شدم") } }, title = { Text("راهنمای پنجره شناور") }, text = { Text("• نوار بالای پنجره را بکش تا جابه‌جا شود.\n• گوشه پایین سمت راست را بکش تا اندازه تغییر کند.\n• دکمه‌های −۱۵ و +۱۵ برای عقب و جلو رفتن هستند.\n• دکمه × پنجره و پخش را می‌بندد.\n• برای پخش دوباره، از صفحه اصلی فایل را انتخاب کن.") })
    }
}
