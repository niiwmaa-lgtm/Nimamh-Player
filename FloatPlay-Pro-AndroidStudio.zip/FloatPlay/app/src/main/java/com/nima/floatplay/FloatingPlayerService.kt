package com.nima.floatplay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.ViewTreeLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@UnstableApi
class FloatingPlayerService : LifecycleService() {
    companion object {
        const val ACTION_PLAY = "com.nima.floatplay.PLAY"
        const val ACTION_STOP = "com.nima.floatplay.STOP"
        private const val CHANNEL_ID = "floatplay_media"
        private const val NOTIFICATION_ID = 4102
        private const val PREFS = "floatplay_window"
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null
    private var player: ExoPlayer? = null
    private var isVideoMedia = true
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> { stopPlayback(); return START_NOT_STICKY }
            ACTION_PLAY -> {
                val uri = intent.data
                if (uri != null) {
                    startForeground(NOTIFICATION_ID, buildNotification())
                    startMedia(uri)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startMedia(uri: Uri) {
        isVideoMedia = contentResolver.getType(uri)?.startsWith("video/") == true
        removeOverlay()
        player?.release()
        player = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
            addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { updateNotification() }
                override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) { updateNotification() }
            })
        }
        showOverlay()
    }

    private fun showOverlay() {
        val exo = player ?: return
        val startWidth = prefs.getInt("width", 340).coerceIn(240, 620)
        val startHeight = prefs.getInt("height", 260).coerceIn(150, 700)
        val view = ComposeView(this).apply {
            ViewTreeLifecycleOwner.set(this, this@FloatingPlayerService)
            setContent {
                var playing by remember { mutableStateOf(exo.isPlaying) }
                var duration by remember { mutableLongStateOf(0L) }
                var position by remember { mutableLongStateOf(0L) }
                var boxWidth by remember { mutableIntStateOf(startWidth) }
                var boxHeight by remember { mutableIntStateOf(startHeight) }
                var locked by remember { mutableStateOf(prefs.getBoolean("locked", false)) }
                var collapsed by remember { mutableStateOf(false) }
                var showSettings by remember { mutableStateOf(false) }
                var speed by remember { mutableFloatStateOf(prefs.getFloat("speed", 1f)) }
                var volume by remember { mutableFloatStateOf(prefs.getFloat("volume", 1f)) }
                var brightness by remember { mutableFloatStateOf(prefs.getFloat("brightness", -1f)) }
                var seeking by remember { mutableStateOf(false) }
                var seekPosition by remember { mutableFloatStateOf(0f) }

                DisposableEffect(exo) {
                    val listener = object : Player.Listener {
                        override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                        override fun onPlaybackStateChanged(playbackState: Int) { duration = exo.duration.coerceAtLeast(0L) }
                    }
                    exo.addListener(listener)
                    onDispose { exo.removeListener(listener) }
                }
                LaunchedEffect(exo) {
                    while (true) {
                        if (!seeking) position = exo.currentPosition.coerceAtLeast(0L)
                        duration = exo.duration.coerceAtLeast(0L)
                        delay(350)
                    }
                }
                fun seek(delta: Long) {
                    val max = exo.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                    exo.seekTo((exo.currentPosition + delta).coerceIn(0L, max))
                }
                fun applyWindowSize(w: Int, h: Int) {
                    boxWidth = w.coerceIn(240, 620); boxHeight = h.coerceIn(150, 700)
                    prefs.edit().putInt("width", boxWidth).putInt("height", boxHeight).apply()
                    resizeWindow(boxWidth, boxHeight)
                }
                fun applyBrightness(value: Float) {
                    brightness = value
                    prefs.edit().putFloat("brightness", value).apply()
                    params?.let { p -> p.screenBrightness = if (value < 0f) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else value; try { overlayView?.let { windowManager.updateViewLayout(it, p) } } catch (_: Exception) { } }
                }

                MaterialTheme(colorScheme = darkColorScheme(
                    primary = Color(0xFFD0BCFF), onPrimary = Color(0xFF381E72),
                    surface = Color(0xFF211F26), onSurface = Color(0xFFE6E0E9),
                    secondaryContainer = Color(0xFF4A4458)
                )) {
                    if (collapsed) {
                        Row(Modifier.width(116.dp).height(58.dp).clip(RoundedCornerShape(30.dp)).background(Color(0xFF302B38)).padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                            IconButton(onClick = { if (exo.isPlaying) exo.pause() else exo.play() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "پخش/مکث", tint = Color.White) }
                            IconButton(onClick = { collapsed = false; resizeWindow(boxWidth, boxHeight) }) { Icon(Icons.Default.PictureInPictureAlt, "باز کردن", tint = Color(0xFFD0BCFF)) }
                            IconButton(onClick = { stopPlayback() }) { Icon(Icons.Default.Close, "بستن", tint = Color.White) }
                        }
                    } else {
                        Column(Modifier.width(boxWidth.dp).height(boxHeight.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF211F26)).padding(8.dp)) {
                            Row(Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF38343F))
                                .then(if (!locked) Modifier.pointerInput(Unit) { detectDragGestures { change, drag -> change.consume(); moveWindow(drag.x.roundToInt(), drag.y.roundToInt()) } } else Modifier)
                                .padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.GraphicEq, null, tint = Color(0xFFD0BCFF), modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("FLOATPLAY PRO", color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                IconButton(onClick = { locked = !locked; prefs.edit().putBoolean("locked", locked).apply() }, modifier = Modifier.size(30.dp)) { Icon(if (locked) Icons.Default.Lock else Icons.Default.LockOpen, if (locked) "قفل حرکت" else "بازکردن قفل", tint = Color.White, modifier = Modifier.size(17.dp)) }
                                IconButton(onClick = { collapsed = true; resizeWindow(116, 58) }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Remove, "جمع کردن", tint = Color.White, modifier = Modifier.size(18.dp)) }
                                IconButton(onClick = { stopPlayback() }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Close, "بستن", tint = Color.White, modifier = Modifier.size(18.dp)) }
                            }
                            Box(Modifier.weight(1f).fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black)) {
                                if (isVideoMedia) {
                                    AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = exo; useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING) } }, update = { it.player = exo }, modifier = Modifier.fillMaxSize())
                                } else {
                                    Column(Modifier.fillMaxSize().background(Color(0xFF302B38)), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Icon(Icons.Default.GraphicEq, null, tint = Color(0xFFD0BCFF), modifier = Modifier.size(54.dp))
                                        Text("در حال پخش موسیقی", color = Color.White, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                                Row(Modifier.fillMaxSize()) {
                                    Box(Modifier.weight(1f).fillMaxHeight().pointerInput(Unit) { detectTapGestures(onTap = { seek(-10_000) }) })
                                    Box(Modifier.weight(1f).fillMaxHeight().pointerInput(Unit) { detectTapGestures(onTap = { if (exo.isPlaying) exo.pause() else exo.play() }) })
                                    Box(Modifier.weight(1f).fillMaxHeight().pointerInput(Unit) { detectTapGestures(onTap = { seek(10_000) }) })
                                }
                            }
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(formatTime(if (seeking) seekPosition.toLong() else position), color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(value = if (duration > 0) (if (seeking) seekPosition else position.toFloat()).coerceIn(0f, duration.toFloat()) else 0f,
                                    onValueChange = { seeking = true; seekPosition = it },
                                    onValueChangeFinished = { exo.seekTo(seekPosition.toLong()); position = seekPosition.toLong(); seeking = false },
                                    valueRange = 0f..duration.coerceAtLeast(1L).toFloat(), modifier = Modifier.weight(1f).height(28.dp),
                                    colors = SliderDefaults.colors(thumbColor = Color(0xFFD0BCFF), activeTrackColor = Color(0xFFD0BCFF)))
                                Text(formatTime(duration), color = Color.White, style = MaterialTheme.typography.labelSmall)
                            }
                            Row(Modifier.fillMaxWidth().height(38.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                                IconButton(onClick = { seek(-15_000) }) { Icon(Icons.Default.SkipPrevious, "۱۵ ثانیه عقب", tint = Color.White) }
                                IconButton(onClick = { if (exo.isPlaying) exo.pause() else exo.play() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "پخش/مکث", tint = Color(0xFFD0BCFF), modifier = Modifier.size(29.dp)) }
                                IconButton(onClick = { seek(15_000) }) { Icon(Icons.Default.SkipNext, "۱۵ ثانیه جلو", tint = Color.White) }
                                IconButton(onClick = { showSettings = !showSettings }) { Icon(Icons.Default.Settings, "تنظیمات", tint = Color.White) }
                                IconButton(onClick = { applyWindowSize(boxWidth - 35, boxHeight - 20) }) { Icon(Icons.Default.Remove, "کوچک‌تر", tint = Color.White) }
                                IconButton(onClick = { applyWindowSize(boxWidth + 35, boxHeight + 20) }) { Icon(Icons.Default.Add, "بزرگ‌تر", tint = Color.White) }
                            }
                            if (showSettings) {
                                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF302B38)).padding(horizontal = 10.dp, vertical = 5.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("سرعت", color = Color.White, style = MaterialTheme.typography.labelMedium)
                                        Spacer(Modifier.width(8.dp))
                                        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { rate ->
                                            TextButton(onClick = { speed = rate; exo.setPlaybackSpeed(rate); prefs.edit().putFloat("speed", rate).apply() }, contentPadding = PaddingValues(horizontal = 5.dp)) {
                                                Text(if (speed == rate) "${rate}×" else "${rate}×", color = if (speed == rate) Color(0xFFD0BCFF) else Color.White, style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                    Text("صدای پلیر", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(value = volume, onValueChange = { volume = it; exo.volume = it; prefs.edit().putFloat("volume", it).apply() }, valueRange = 0f..1f)
                                    Text("روشنایی پنجره  •  برای حالت پیش‌فرض، تا انتها کم کن", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(value = if (brightness < 0f) 1f else brightness, onValueChange = { applyBrightness(it) }, valueRange = 0.1f..1f)
                                }
                            }
                            Box(Modifier.fillMaxWidth().height(13.dp).then(if (!locked) Modifier.pointerInput(Unit) { detectDragGestures { change, drag -> change.consume(); applyWindowSize(boxWidth + drag.x.roundToInt(), boxHeight + drag.y.roundToInt()) } } else Modifier), contentAlignment = Alignment.CenterEnd) {
                                Box(Modifier.size(10.dp).clip(CircleShape).background(if (locked) Color.Gray else Color(0xFFD0BCFF)))
                            }
                        }
                    }
                }
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(startWidth), dp(startHeight),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", dp(18)); y = prefs.getInt("y", dp(120))
            screenBrightness = prefs.getFloat("brightness", -1f).let { if (it < 0f) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else it }
        }
        try { windowManager.addView(view, lp); overlayView = view; params = lp }
        catch (_: Exception) { stopPlayback() }
    }

    private fun formatTime(ms: Long): String {
        if (ms < 0) return "00:00"
        val seconds = ms / 1000
        return if (seconds >= 3600) String.format("%d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
        else String.format("%02d:%02d", seconds / 60, seconds % 60)
    }

    private fun moveWindow(dx: Int, dy: Int) {
        val p = params ?: return
        p.x += dx; p.y += dy
        try { overlayView?.let { windowManager.updateViewLayout(it, p) }; prefs.edit().putInt("x", p.x).putInt("y", p.y).apply() } catch (_: Exception) { }
    }

    private fun resizeWindow(widthDp: Int, heightDp: Int) {
        val p = params ?: return
        p.width = dp(widthDp); p.height = dp(heightDp)
        try { overlayView?.let { windowManager.updateViewLayout(it, p) } } catch (_: Exception) { }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    private fun removeOverlay() { overlayView?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }; overlayView = null; params = null }
    private fun stopPlayback() { removeOverlay(); player?.release(); player = null; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID, "پخش رسانه FloatPlay", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1, Intent(this, FloatingPlayerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("FloatPlay Pro در حال پخش").setContentText("رسانه در پنجره شناور پخش می‌شود")
            .setContentIntent(open).setOngoing(true).addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stop)
            .setPriority(NotificationCompat.PRIORITY_LOW).build()
    }
    private fun updateNotification() { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification()) }
    override fun onDestroy() { removeOverlay(); player?.release(); player = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)
}
