# FloatPlay Pro — Android Studio project

FloatPlay Pro is an Android floating audio/video player built with Kotlin, Jetpack Compose, Material 3 and AndroidX Media3 (ExoPlayer).

## Features in this source version

- Open one local audio or video file through Android's Storage Access Framework (no broad storage permission).
- Draw-over-other-apps floating window using `SYSTEM_ALERT_WINDOW`.
- Foreground media-playback service and persistent playback notification.
- Drag the title bar to move the window; position is saved.
- Resize using +/- controls or the bottom-right handle; dimensions are saved.
- Collapse to a compact mini-player bubble and expand again.
- Lock/unlock movement and resizing.
- Tap left/center/right areas of the video to seek -10s / play-pause / seek +10s.
- Dedicated -15s / +15s buttons and a seek bar with elapsed/total time.
- Playback speed: 0.5x, 0.75x, 1x, 1.25x, 1.5x and 2x.
- Player volume control and per-window brightness control.
- Material 3 dark styling in the floating player; Material 3 app screen.
- Window size, position, lock state, speed, volume and brightness are persisted locally.

## Requirements

- Android Studio (current stable version recommended)
- JDK 17
- Android SDK Platform 35 (the project uses `compileSdk = 35`)
- Internet connection on first Gradle sync to download dependencies
- Android 8.0 / API 26 or newer for the app's declared minimum SDK

The repository does not include a prebuilt APK or Gradle wrapper. Build it locally using Android Studio as described below.

## Step-by-step: build a debug APK

1. Download `FloatPlay-Pro-AndroidStudio.zip` and extract it to a normal folder, for example `Documents/AndroidProjects/`.
2. Open Android Studio.
3. Choose **File → Open** (or **Open**) and select the extracted `FloatPlay` folder — the folder containing `settings.gradle.kts`.
4. If Android Studio asks whether to trust the project, choose **Trust Project**.
5. If it asks for a JDK, select **Embedded JDK 17**: **Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK**.
6. Open **Tools → SDK Manager**. In **SDK Platforms**, install **Android 15 / API 35**. In **SDK Tools**, ensure Android SDK Build-Tools and Platform-Tools are installed. Apply changes.
7. Press **Sync Project with Gradle Files** (elephant icon) and wait for the first sync to finish. The first sync may take several minutes because Android Studio downloads Android Gradle Plugin, Kotlin, Compose and Media3 dependencies.
8. Resolve any SDK/JDK prompt shown by Android Studio, then wait until the bottom status bar reports that Gradle sync has finished.
9. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
10. Wait for the build to finish. Android Studio normally shows an **APK(s) generated successfully** notification. Click **Locate** in that notification.
11. The debug APK is normally at `FloatPlay/app/build/outputs/apk/debug/app-debug.apk`.
12. Copy the APK to the Android phone and install it. If Android blocks installation, allow **Install unknown apps** for the file manager/browser you used, then retry.

## Step-by-step: install and first launch

1. Launch **FloatPlay Pro**.
2. Tap **انتخاب فایل صوتی یا تصویری** and choose a local media file in the Android file picker.
3. Tap **فعال‌سازی مجوز شناور**. Android opens the special access page for **Display over other apps**; enable it for FloatPlay Pro and return to the app.
4. If Android 13 or newer asks for notification permission, allow it so the playback notification can be shown.
5. Tap **پخش در پنجره شناور**. The player should appear above other apps.
6. Drag the top bar to move it. Use the +/- controls or the bottom-right handle to resize it. Use the lock icon to disable moving/resizing.
7. Tap the minus/collapse icon to reduce it to a mini-player; tap expand to restore it.
8. Open the gear/settings control for speed, player volume and overlay brightness.
9. Use the notification's Stop action or the X button to stop playback and remove the overlay.

## Important notes / known limitations

- This is a source project, not a tested release APK. It has not been compiled or device-tested in this environment; build it in Android Studio and test on the target phone before relying on it.
- The overlay permission is granted manually by the user in Android Settings. Android may restrict background starts or overlay behavior depending on OS version and manufacturer battery policies.
- The current build opens one selected file at a time. Playlist/queue management, subtitle selection, audio-track selection, equalizer, lock-screen MediaSession controls, casting, network streams and persistent resume-after-reboot are not included yet.
- The brightness slider changes the overlay window's screen-brightness hint. Some Android skins may ignore or reinterpret this setting.
- Video seeking by tapping the left/right thirds is supported; the middle third toggles play/pause.
- Some unusual codecs/containers may not be supported by the device's media decoders.
- The project uses AndroidX Media3 ExoPlayer. Do not remove the Media3 dependencies from `app/build.gradle.kts`.

## Troubleshooting

- **Gradle sync fails:** check internet access, JDK 17 and SDK Platform 35. Use **File → Sync Project with Gradle Files** again after fixing the cause.
- **SDK 35 missing:** open SDK Manager and install Android 15 / API 35.
- **Overlay does not appear:** revisit Android Settings → Apps → Special app access → Display over other apps → FloatPlay Pro and enable it.
- **Playback stops when screen is off:** check the phone manufacturer's battery optimization/autostart settings for FloatPlay Pro. Behavior varies by device.
- **APK installs but app crashes:** capture Logcat in Android Studio and inspect the first `FATAL EXCEPTION`; test with a common MP3 or MP4 file first.

## Project structure

- `app/src/main/java/com/nima/floatplay/MainActivity.kt` — app screen and file picker.
- `app/src/main/java/com/nima/floatplay/FloatingPlayerService.kt` — media service and floating player UI.
- `app/src/main/AndroidManifest.xml` — permissions, launcher activity and foreground service declaration.
- `app/build.gradle.kts` — Android, Compose and Media3 dependencies.
