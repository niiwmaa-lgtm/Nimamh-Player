package com.example.floatingplayer

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    /** 0 = compact, 1 = normal, 2 = wide */
    fun size(c: Context) = sp(c).getInt("size", 1)
    fun setSize(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()

    /** 50..100 */
    fun opacity(c: Context) = sp(c).getInt("opacity", 100)
    fun setOpacity(c: Context, v: Int) = sp(c).edit().putInt("opacity", v).apply()

    fun autoClose(c: Context) = sp(c).getBoolean("autoClose", true)
    fun setAutoClose(c: Context, v: Boolean) = sp(c).edit().putBoolean("autoClose", v).apply()

    fun remember(c: Context) = sp(c).getBoolean("remember", true)
    fun setRemember(c: Context, v: Boolean) = sp(c).edit().putBoolean("remember", v).apply()

    fun hasPos(c: Context) = sp(c).contains("x")
    fun posX(c: Context) = sp(c).getInt("x", 0)
    fun posY(c: Context) = sp(c).getInt("y", 0)
    fun savePos(c: Context, x: Int, y: Int) = sp(c).edit().putInt("x", x).putInt("y", y).apply()
}
