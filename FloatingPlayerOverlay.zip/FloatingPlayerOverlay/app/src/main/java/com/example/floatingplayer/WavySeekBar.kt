package com.example.floatingplayer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * Material You style seek bar. Two looks:
 *  - wave: the played part is an animated wave, the rest a straight line
 *  - bars: a waveform of the audio
 * Touch or drag anywhere to jump. Can show bookmark markers and an A-B region.
 */
class WavySeekBar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onScrubStart()
        fun onScrub(positionMs: Long)
        fun onScrubEnd(positionMs: Long)
    }

    var listener: Listener? = null

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private var waveColor = Color.parseColor("#6750A4")
    private var trackColor = Color.parseColor("#CAC4D0")
    private var markColor = Color.parseColor("#7D5260")

    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = dp(4f)
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = dp(4f)
    }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = dp(3f)
    }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()

    private var durationMs = 0L
    private var positionMs = 0L
    private var scrubbing = false
    private var playing = false
    private var amp = 0f
    private var phase = 0f

    private var peaks: FloatArray? = null
    private var bars = false
    private var markers: List<Long> = emptyList()
    private var abA = -1L
    private var abB = -1L

    private val phaseAnimator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 1500
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }
    private var ampAnimator: ValueAnimator? = null

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.WavySeekBar)
        waveColor = a.getColor(R.styleable.WavySeekBar_seekWaveColor, waveColor)
        trackColor = a.getColor(R.styleable.WavySeekBar_seekTrackColor, trackColor)
        markColor = a.getColor(R.styleable.WavySeekBar_seekMarkColor, markColor)
        a.recycle()
        isEnabled = false
        alpha = 0.5f
    }

    fun setPlaying(p: Boolean) {
        if (playing == p) return
        playing = p
        ampAnimator?.cancel()
        ampAnimator = ValueAnimator.ofFloat(amp, if (p) 1f else 0f).apply {
            duration = 350
            addUpdateListener {
                amp = it.animatedValue as Float
                if (!playing && amp <= 0.001f) phaseAnimator.cancel()
                invalidate()
            }
            start()
        }
        if (p) startPhase()
    }

    fun setPeaks(p: FloatArray?) {
        peaks = p
        invalidate()
    }

    fun setBars(b: Boolean) {
        bars = b
        invalidate()
    }

    fun setMarkers(m: List<Long>) {
        markers = ArrayList(m)
        invalidate()
    }

    fun setAb(a: Long, b: Long) {
        abA = a
        abB = b
        invalidate()
    }

    /** Called from the player; ignored while the user is scrubbing. */
    fun setProgress(pos: Long, dur: Long) {
        durationMs = if (dur > 0) dur else 0L
        val enabledNow = durationMs > 0
        if (isEnabled != enabledNow) {
            isEnabled = enabledNow
            alpha = if (enabledNow) 1f else 0.5f
        }
        if (!scrubbing) {
            positionMs = if (durationMs > 0) pos.coerceIn(0L, durationMs) else 0L
            invalidate()
        }
    }

    private fun startPhase() {
        if (isAttachedToWindow && !phaseAnimator.isStarted) phaseAnimator.start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (playing) startPhase()
    }

    override fun onDetachedFromWindow() {
        phaseAnimator.cancel()
        ampAnimator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize(dp(200f).toInt(), widthMeasureSpec),
            resolveSize(dp(40f).toInt(), heightMeasureSpec)
        )
    }

    private fun xFor(ms: Long, left: Float, right: Float): Float =
        if (durationMs > 0) left + (right - left) * (ms.toFloat() / durationMs) else left

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cy = height / 2f
        val pad = dp(10f)
        val left = pad
        val right = w - pad
        val frac = if (durationMs > 0) positionMs.toFloat() / durationMs else 0f
        val px = left + (right - left) * frac
        val half = height / 2f - dp(3f)

        // A-B region
        if (abA >= 0 && durationMs > 0) {
            val x1 = xFor(abA, left, right)
            bandPaint.color = markColor
            bandPaint.alpha = 70
            if (abB > abA) {
                val x2 = xFor(abB, left, right)
                canvas.drawRoundRect(x1, cy - half, x2, cy + half, dp(6f), dp(6f), bandPaint)
            } else {
                canvas.drawRoundRect(x1 - dp(1.5f), cy - half, x1 + dp(1.5f), cy + half, dp(1.5f), dp(1.5f), bandPaint)
            }
        }

        if (bars) drawBars(canvas, left, right, cy, px) else drawWave(canvas, left, right, cy, px)

        // bookmarks
        if (durationMs > 0 && markers.isNotEmpty()) {
            markPaint.color = markColor
            for (m in markers) {
                canvas.drawCircle(xFor(m, left, right), cy - half, dp(2.6f), markPaint)
            }
        }

        // thumb
        thumbPaint.color = waveColor
        val tw = if (scrubbing) dp(6f) else dp(4f)
        val th = if (scrubbing) (height - dp(8f)).coerceAtMost(dp(44f)) else (height - dp(12f)).coerceAtMost(dp(36f))
        canvas.drawRoundRect(px - tw / 2, cy - th / 2, px + tw / 2, cy + th / 2, tw / 2, tw / 2, thumbPaint)
    }

    private fun drawWave(canvas: Canvas, left: Float, right: Float, cy: Float, px: Float) {
        val gap = dp(6f)

        trackPaint.color = trackColor
        if (px + gap < right) canvas.drawLine(px + gap, cy, right, cy, trackPaint)

        val end = px - gap
        if (end > left) {
            val wavelength = dp(30f)
            val taper = ((end - left) / dp(36f)).coerceIn(0f, 1f)
            val ampPx = dp(3.2f) * amp * taper
            val k = (2 * PI / wavelength).toFloat()
            path.reset()
            var x = left
            path.moveTo(x, cy + ampPx * sin(k * (x - left) - phase))
            while (x < end) {
                x = minOf(x + dp(2f), end)
                path.lineTo(x, cy + ampPx * sin(k * (x - left) - phase))
            }
            wavePaint.color = waveColor
            canvas.drawPath(path, wavePaint)
        }
    }

    private fun drawBars(canvas: Canvas, left: Float, right: Float, cy: Float, px: Float) {
        val step = dp(5f)
        val n = ((right - left) / step).toInt().coerceAtLeast(1)
        val pk = peaks
        for (i in 0 until n) {
            val x = left + i * step + dp(1.5f)
            var v = 0f
            if (pk != null && pk.isNotEmpty()) {
                val a = (i.toLong() * pk.size / n).toInt()
                val b = (((i + 1).toLong() * pk.size / n).toInt()).coerceAtLeast(a + 1).coerceAtMost(pk.size)
                for (k in a until b) if (pk[k] > v) v = pk[k]
            }
            val h = dp(4f) + v * (height - dp(16f))
            barPaint.color = if (x <= px) waveColor else trackColor
            canvas.drawLine(x, cy - h / 2, x, cy + h / 2, barPaint)
        }
    }

    private fun updateFrom(x: Float) {
        val pad = dp(10f)
        val f = ((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        positionMs = (f * durationMs).toLong()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled || durationMs <= 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                scrubbing = true
                updateFrom(e.x)
                listener?.onScrubStart()
                listener?.onScrub(positionMs)
            }
            MotionEvent.ACTION_MOVE -> {
                updateFrom(e.x)
                listener?.onScrub(positionMs)
            }
            MotionEvent.ACTION_UP -> {
                updateFrom(e.x)
                scrubbing = false
                listener?.onScrubEnd(positionMs)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                scrubbing = false
                listener?.onScrubEnd(positionMs)
                invalidate()
            }
        }
        return true
    }
}
