package com.example.floatingplayer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * Material You style seek bar: the played part is an animated wave (while playing),
 * the rest is a straight line. Touch or drag anywhere to jump.
 */
class WavySeekBar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onScrubStart()
        fun onScrub(positionMs: Long)
        fun onScrubEnd(positionMs: Long)
    }

    var listener: Listener? = null

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private var waveColor = Color.parseColor("#6750A4")
    private var trackColor = Color.parseColor("#CAC4D0")

    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = dp(4f)
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = dp(4f)
    }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()

    private var durationMs = 0L
    private var positionMs = 0L
    private var scrubbing = false
    private var playing = false
    private var amp = 0f
    private var phase = 0f

    private val phaseAnimator = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 1500
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }
    private var ampAnimator: ValueAnimator? = null

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.WavySeekBar)
        waveColor = a.getColor(R.styleable.WavySeekBar_seekWaveColor, waveColor)
        trackColor = a.getColor(R.styleable.WavySeekBar_seekTrackColor, trackColor)
        a.recycle()
        isEnabled = false
        alpha = 0.5f
    }

    fun setPlaying(p: Boolean) {
        if (playing == p) return
        playing = p
        ampAnimator?.cancel()
        ampAnimator = ValueAnimator.ofFloat(amp, if (p) 1f else 0f).apply {
            duration = 350
            addUpdateListener {
                amp = it.animatedValue as Float
                if (!playing && amp <= 0.001f) phaseAnimator.cancel()
                invalidate()
            }
            start()
        }
        if (p) startPhase()
    }

    /** Called from the player; ignored while the user is scrubbing. */
    fun setProgress(pos: Long, dur: Long) {
        durationMs = if (dur > 0) dur else 0L
        val enabledNow = durationMs > 0
        if (isEnabled != enabledNow) {
            isEnabled = enabledNow
            alpha = if (enabledNow) 1f else 0.5f
        }
        if (!scrubbing) {
            positionMs = if (durationMs > 0) pos.coerceIn(0L, durationMs) else 0L
            invalidate()
        }
    }

    private fun startPhase() {
        if (isAttachedToWindow && !phaseAnimator.isStarted) phaseAnimator.start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (playing) startPhase()
    }

    override fun onDetachedFromWindow() {
        phaseAnimator.cancel()
        ampAnimator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize(dp(200f).toInt(), widthMeasureSpec),
            resolveSize(dp(40f).toInt(), heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cy = height / 2f
        val pad = dp(10f)
        val left = pad
        val right = w - pad
        val frac = if (durationMs > 0) positionMs.toFloat() / durationMs else 0f
        val px = left + (right - left) * frac
        val gap = dp(6f)

        // remaining part: straight line
        trackPaint.color = trackColor
        if (px + gap < right) canvas.drawLine(px + gap, cy, right, cy, trackPaint)

        // played part: wave
        val end = px - gap
        if (end > left) {
            val wavelength = dp(30f)
            val ampPx = dp(3.2f) * amp
            val k = (2 * PI / wavelength).toFloat()
            path.reset()
            var x = left
            path.moveTo(x, cy + ampPx * sin(k * (x - left) - phase))
            while (x < end) {
                x = minOf(x + dp(2f), end)
                path.lineTo(x, cy + ampPx * sin(k * (x - left) - phase))
            }
            wavePaint.color = waveColor
            canvas.drawPath(path, wavePaint)
        }

        // thumb
        thumbPaint.color = waveColor
        val tw = if (scrubbing) dp(6f) else dp(4f)
        val th = if (scrubbing) dp(30f) else dp(26f)
        canvas.drawRoundRect(px - tw / 2, cy - th / 2, px + tw / 2, cy + th / 2, tw / 2, tw / 2, thumbPaint)
    }

    private fun updateFrom(x: Float) {
        val pad = dp(10f)
        val f = ((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        positionMs = (f * durationMs).toLong()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled || durationMs <= 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                scrubbing = true
                updateFrom(e.x)
                listener?.onScrubStart()
                listener?.onScrub(positionMs)
            }
            MotionEvent.ACTION_MOVE -> {
                updateFrom(e.x)
                listener?.onScrub(positionMs)
            }
            MotionEvent.ACTION_UP -> {
                updateFrom(e.x)
                scrubbing = false
                listener?.onScrubEnd(positionMs)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                scrubbing = false
                listener?.onScrubEnd(positionMs)
                invalidate()
            }
        }
        return true
    }
}
