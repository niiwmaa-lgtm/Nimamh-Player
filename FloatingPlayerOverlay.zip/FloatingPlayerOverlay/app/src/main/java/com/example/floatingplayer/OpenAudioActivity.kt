package com.example.floatingplayer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.IntentCompat

/** Invisible activity: receives an audio file (open / share) and hands it to the overlay service. */
class OpenAudioActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val uris = ArrayList<Uri>()
        if (i != null) {
            if (i.action == Intent.ACTION_SEND) {
                val u = IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
                if (u != null) uris.add(u)
            } else {
                val d = i.data
                if (d != null) uris.add(d)
            }
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.toast_need_overlay, Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        if (uris.isNotEmpty()) OverlayPlayerService.start(this, uris)
        finish()
    }
}
