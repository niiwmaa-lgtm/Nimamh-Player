package com.example.floatingplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.OpenableColumns
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.DynamicColors
import java.util.Locale

class OverlayPlayerService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var nm: NotificationManager
    private lateinit var params: WindowManager.LayoutParams

    private var overlay: ResizeFrameLayout? = null
    private var player: ExoPlayer? = null

    private lateinit var cardView: View
    private lateinit var contentView: View
    private lateinit var artView: ImageView
    private lateinit var artBig: ImageView
    private lateinit var artSmallCard: View
    private lateinit var artBigCard: View
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var seekBar: WavySeekBar
    private lateinit var timeNow: TextView
    private lateinit var timeTotal: TextView
    private lateinit var playBtn: MaterialButton
    private lateinit var prevBtn: MaterialButton
    private lateinit var nextBtn: MaterialButton
    private lateinit var speedBtn: MaterialButton

    private var scrubbing = false
    private var speedIndex = 0
    private var currentTitle = ""
    private var currentArtist = ""

    // window size state
    private var expanded = false   // taller than the content -> big artwork is shown
    private var minH = 0           // height of the window when it just wraps its content

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 300)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW)
        )
        currentTitle = getString(R.string.app_name)
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                player?.let { if (it.isPlaying) it.pause() else it.play() }
                return START_NOT_STICKY
            }
        }

        val uris = if (intent != null) extractUris(intent) else emptyList()
        if (uris.isEmpty()) {
            if (overlay == null) stopSelf()
            return START_NOT_STICKY
        }
        if (overlay == null) createOverlay()
        playQueue(uris)
        return START_NOT_STICKY
    }

    private fun extractUris(i: Intent): List<Uri> {
        val out = ArrayList<Uri>()
        val cd = i.clipData
        if (cd != null) {
            for (k in 0 until cd.itemCount) {
                val u = cd.getItemAt(k).uri
                if (u != null) out.add(u)
            }
        }
        if (out.isEmpty()) {
            val d = i.data
            if (d != null) out.add(d)
        }
        return out
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ overlay UI

    private fun createOverlay() {
        val themed = DynamicColors.wrapContextIfAvailable(
            ContextThemeWrapper(this, R.style.Theme_FloatingPlayer)
        )
        val view = LayoutInflater.from(themed).inflate(R.layout.overlay_player, null) as ResizeFrameLayout
        overlay = view

        cardView = view.findViewById(R.id.card)
        contentView = view.findViewById(R.id.content)
        artView = view.findViewById(R.id.art)
        artBig = view.findViewById(R.id.art_big)
        artSmallCard = view.findViewById(R.id.art_card)
        artBigCard = view.findViewById(R.id.art_big_card)
        titleView = view.findViewById<TextView>(R.id.title).also { it.isSelected = true }
        artistView = view.findViewById(R.id.artist)
        seekBar = view.findViewById(R.id.seek)
        timeNow = view.findViewById(R.id.time_now)
        timeTotal = view.findViewById(R.id.time_total)
        playBtn = view.findViewById(R.id.play)
        prevBtn = view.findViewById(R.id.prev)
        nextBtn = view.findViewById(R.id.next)
        speedBtn = view.findViewById(R.id.speed)
        val rewindBtn = view.findViewById<MaterialButton>(R.id.rewind)
        val forwardBtn = view.findViewById<MaterialButton>(R.id.forward)
        val closeBtn = view.findViewById<MaterialButton>(R.id.close)

        // AMR (and some MP3/ADTS) files have no duration/seek table. Constant-bitrate seeking
        // lets the player estimate the duration and seek in them.
        val extractors = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
        val p = ExoPlayer.Builder(this, DefaultMediaSourceFactory(this, extractors))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player = p

        p.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val uri = mediaItem?.localConfiguration?.uri
                currentTitle = if (uri != null) displayName(uri) else getString(R.string.unknown_track)
                currentArtist = ""
                titleView.text = currentTitle
                artistView.text = currentArtist
                setArt(null)
                updateNotification()
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                val t = mediaMetadata.title?.toString()
                if (!t.isNullOrBlank()) {
                    currentTitle = t
                    titleView.text = t
                }
                val a = (mediaMetadata.artist ?: mediaMetadata.albumArtist)?.toString()
                if (!a.isNullOrBlank()) {
                    currentArtist = a
                    artistView.text = a
                }
                val art = mediaMetadata.artworkData
                if (art != null) setArt(art)
                updateNotification()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playBtn.setIconResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                seekBar.setPlaying(isPlaying)
                updateNotification()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && Prefs.autoClose(this@OverlayPlayerService)) {
                    stopSelf()
                }
                updateProgress()
            }

            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(applicationContext, R.string.toast_play_error, Toast.LENGTH_SHORT).show()
            }
        })

        // --- buttons
        closeBtn.setOnClickListener { stopSelf() }

        playBtn.setOnClickListener {
            when {
                p.playbackState == Player.STATE_ENDED -> {
                    p.seekTo(0, 0L)
                    p.play()
                }
                p.isPlaying -> p.pause()
                else -> p.play()
            }
        }
        rewindBtn.setOnClickListener {
            p.seekTo((p.currentPosition - SKIP_MS).coerceAtLeast(0L))
        }
        forwardBtn.setOnClickListener {
            val d = p.duration
            val t = p.currentPosition + SKIP_MS
            p.seekTo(if (d != C.TIME_UNSET) minOf(t, d) else t)
        }
        prevBtn.setOnClickListener { p.seekToPrevious() }
        nextBtn.setOnClickListener { p.seekToNext() }

        speedBtn.setOnClickListener {
            speedIndex = (speedIndex + 1) % SPEEDS.size
            val s = SPEEDS[speedIndex]
            p.playbackParameters = PlaybackParameters(s)
            speedBtn.text = speedLabel(s)
        }
        speedBtn.text = speedLabel(SPEEDS[0])

        // --- seek by touching / dragging the wavy bar
        seekBar.listener = object : WavySeekBar.Listener {
            override fun onScrubStart() {
                scrubbing = true
            }

            override fun onScrub(positionMs: Long) {
                timeNow.text = fmt(positionMs)
            }

            override fun onScrubEnd(positionMs: Long) {
                p.seekTo(positionMs)
                scrubbing = false
            }
        }

        // --- window geometry
        val dm = resources.displayMetrics
        val remember = Prefs.remember(this)
        val frac = when (Prefs.size(this)) {
            0 -> 0.82f
            2 -> 0.98f
            else -> 0.92f
        }
        val width = if (remember && Prefs.hasSize(this)) {
            Prefs.sizeW(this).coerceIn(dp(MIN_W_DP), dm.widthPixels)
        } else {
            (dm.widthPixels * frac).toInt()
        }

        // height of the window when it only wraps its content
        view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        minH = view.measuredHeight

        val maxH = (dm.heightPixels * 0.92f).toInt()
        val savedH = if (remember) Prefs.sizeH(this) else 0
        val expandNow = savedH > minH + dp(16)
        val height = if (expandNow) savedH.coerceAtMost(maxH) else WindowManager.LayoutParams.WRAP_CONTENT
        if (expandNow) setExpanded(true)
        val winH = if (expandNow) height else minH

        params = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = Prefs.opacity(this@OverlayPlayerService) / 100f
            if (remember && Prefs.hasPos(this@OverlayPlayerService)) {
                x = Prefs.posX(this@OverlayPlayerService).coerceIn(0, maxOf(0, dm.widthPixels - width))
                y = Prefs.posY(this@OverlayPlayerService).coerceIn(0, maxOf(0, dm.heightPixels - winH))
            } else {
                x = (dm.widthPixels - width) / 2
                y = (dm.heightPixels * 0.12f).toInt()
            }
        }

        attachDrag(view.findViewById(R.id.handle), view)
        attachDrag(view.findViewById(R.id.header), view)
        attachResize(view)

        wm.addView(view, params)
        handler.post(ticker)
    }

    /** Move the window by dragging the handle or the header. */
    private fun attachDrag(target: View, root: View) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        target.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    move(root, startX + (e.rawX - touchX).toInt(), startY + (e.rawY - touchY).toInt())
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    savePlacement()
                    true
                }
                else -> false
            }
        }
    }

    private fun move(root: View, x: Int, y: Int) {
        val dm = resources.displayMetrics
        params.x = x.coerceIn(0, maxOf(0, dm.widthPixels - params.width))
        params.y = y.coerceIn(0, maxOf(0, dm.heightPixels - root.height))
        wm.updateViewLayout(root, params)
    }

    /** Resize the window by dragging any edge or the bottom corner. */
    private fun attachResize(view: ResizeFrameLayout) {
        var edges = 0
        var startX = 0
        var startY = 0
        var startW = 0
        var startH = 0
        var touchX = 0f
        var touchY = 0f

        view.callback = object : ResizeFrameLayout.Callback {
            override fun onResizeStart(e: Int, rawX: Float, rawY: Float) {
                edges = e
                startX = params.x
                startY = params.y
                startW = params.width
                startH = view.height
                touchX = rawX
                touchY = rawY
                if (!expanded && view.height > 0) minH = view.height
            }

            override fun onResize(rawX: Float, rawY: Float) {
                val dm = resources.displayMetrics
                val dx = (rawX - touchX).toInt()
                val dy = (rawY - touchY).toInt()
                val minW = dp(MIN_W_DP)
                val maxH = (dm.heightPixels * 0.92f).toInt()

                var w = startW
                var h = startH
                if ((edges and ResizeFrameLayout.LEFT) != 0) w = startW - dx
                if ((edges and ResizeFrameLayout.RIGHT) != 0) w = startW + dx
                if ((edges and ResizeFrameLayout.TOP) != 0) h = startH - dy
                if ((edges and ResizeFrameLayout.BOTTOM) != 0) h = startH + dy

                w = w.coerceIn(minW, dm.widthPixels)
                val collapsed = h <= minH + dp(16)
                h = if (collapsed) minH else h.coerceAtMost(maxH)

                var x = startX
                var y = startY
                if ((edges and ResizeFrameLayout.LEFT) != 0) x = startX + startW - w
                if ((edges and ResizeFrameLayout.TOP) != 0) y = startY + startH - h

                params.width = w
                params.height = if (collapsed) WindowManager.LayoutParams.WRAP_CONTENT else h
                params.x = x.coerceIn(0, maxOf(0, dm.widthPixels - w))
                params.y = y.coerceIn(0, maxOf(0, dm.heightPixels - h))
                setExpanded(!collapsed)
                wm.updateViewLayout(view, params)
            }

            override fun onResizeEnd() {
                edges = 0
                savePlacement()
            }
        }
    }

    /** Tall window: show the big artwork and hide the small one. */
    private fun setExpanded(e: Boolean) {
        if (expanded == e) return
        expanded = e
        artBigCard.visibility = if (e) View.VISIBLE else View.GONE
        artSmallCard.visibility = if (e) View.GONE else View.VISIBLE
        val h = if (e) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT
        val lp1 = cardView.layoutParams
        lp1.height = h
        cardView.layoutParams = lp1
        val lp2 = contentView.layoutParams
        lp2.height = h
        contentView.layoutParams = lp2
    }

    private fun savePlacement() {
        if (!Prefs.remember(this)) return
        Prefs.savePos(this, params.x, params.y)
        Prefs.saveSize(this, params.width, if (expanded) params.height else 0)
    }

    // ------------------------------------------------------------------ playback

    private fun playQueue(uris: List<Uri>) {
        val p = player ?: return
        p.setMediaItems(uris.map { MediaItem.fromUri(it) })
        p.prepare()
        p.play()
    }

    private fun updateProgress() {
        val p = player ?: return
        val dur = if (p.duration == C.TIME_UNSET || p.duration < 0) 0L else p.duration
        val known = dur > 0
        val pos = if (known) p.currentPosition.coerceIn(0L, dur) else maxOf(p.currentPosition, 0L)

        seekBar.setProgress(pos, dur)
        if (!scrubbing) timeNow.text = fmt(pos)
        timeTotal.text = if (known) fmt(dur) else "--:--"

        val vis = if (p.mediaItemCount > 1) View.VISIBLE else View.GONE
        prevBtn.visibility = vis
        nextBtn.visibility = vis
    }

    private fun setArt(data: ByteArray?) {
        val bmp: Bitmap? = if (data == null) null else try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 640 && bounds.outHeight / (sample * 2) >= 640) sample *= 2
            BitmapFactory.decodeByteArray(data, 0, data.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Exception) {
            null
        }
        bindArt(artView, bmp, false)
        bindArt(artBig, bmp, true)
    }

    private fun bindArt(iv: ImageView, bmp: Bitmap?, big: Boolean) {
        if (bmp != null) {
            iv.setPadding(0, 0, 0, 0)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(bmp)
        } else {
            val pad = if (big) dp(56) else 0
            iv.setPadding(pad, pad, pad, pad)
            iv.scaleType = if (big) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER
            iv.setImageResource(R.drawable.ic_music_note)
        }
    }

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c ->
                        if (c.moveToFirst()) {
                            val n = c.getString(0)
                            if (!n.isNullOrBlank()) return n
                        }
                    }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: getString(R.string.unknown_track)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private fun speedLabel(s: Float): String =
        (if (s == s.toInt().toFloat()) s.toInt().toString() else s.toString()) + "×"

    // ------------------------------------------------------------------ notification

    private fun buildNotification(): Notification {
        val playing = player?.isPlaying == true
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val toggle = PendingIntent.getService(
            this, 1, Intent(this, OverlayPlayerService::class.java).setAction(ACTION_TOGGLE), flags
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, OverlayPlayerService::class.java).setAction(ACTION_STOP), flags
        )
        val open = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), flags)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_player)
            .setContentTitle(currentTitle)
            .setContentText(currentArtist.ifBlank { getString(R.string.notif_playing) })
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play,
                getString(if (playing) R.string.action_pause else R.string.action_play),
                toggle
            )
            .addAction(R.drawable.ic_close, getString(R.string.action_stop), stop)
            .build()
    }

    private fun updateNotification() {
        nm.notify(NOTIF_ID, buildNotification())
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "floating_player"
        private const val NOTIF_ID = 1
        private const val ACTION_STOP = "com.example.floatingplayer.STOP"
        private const val ACTION_TOGGLE = "com.example.floatingplayer.TOGGLE"
        private const val SKIP_MS = 10_000L
        private const val MIN_W_DP = 240
        private val SPEEDS = floatArrayOf(1f, 1.25f, 1.5f, 2f, 0.75f)

        /** Start (or update) the floating player with one or more audio files. */
        fun start(ctx: Context, uris: List<Uri>) {
            val i = Intent(ctx, OverlayPlayerService::class.java)
            val clip = ClipData.newRawUri("audio", uris.first())
            for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
            i.clipData = clip
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ContextCompat.startForegroundService(ctx, i)
        }
    }
}
