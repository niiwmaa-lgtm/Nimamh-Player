package com.example.floatingplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.OpenableColumns
import android.util.TypedValue
import android.view.ContextThemeWrapper
import android.view.GestureDetector
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.DynamicColors
import com.google.android.material.progressindicator.CircularProgressIndicator
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class OverlayPlayerService : Service() {

    private enum class Mode { FLOATING, FULLSCREEN, BUBBLE }

    private lateinit var wm: WindowManager
    private lateinit var nm: NotificationManager
    private lateinit var themedCtx: Context
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private var overlay: ResizeFrameLayout? = null
    private var bubble: View? = null
    private var bubbleArt: ImageView? = null
    private var bubbleBadge: ImageView? = null
    private var bubbleRing: CircularProgressIndicator? = null

    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private var mode = Mode.FLOATING

    // ---- views
    private lateinit var cardView: MaterialCardView
    private lateinit var contentView: View
    private lateinit var artView: ImageView
    private lateinit var artBig: ImageView
    private lateinit var artSmallCard: View
    private lateinit var artBigCard: View
    private lateinit var queueList: ListView
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var seekBar: WavySeekBar
    private lateinit var seekGroup: View
    private lateinit var timeNow: TextView
    private lateinit var timeTotal: TextView
    private lateinit var controlsRow: View
    private lateinit var toolsScroll: View
    private lateinit var toolsBox: LinearLayout
    private lateinit var bottomBar: View
    private lateinit var moreBtn: MaterialButton
    private lateinit var playBtn: MaterialButton
    private lateinit var prevBtn: MaterialButton
    private lateinit var nextBtn: MaterialButton
    private lateinit var speedBtn: MaterialButton
    private lateinit var rewindBtn: MaterialButton
    private lateinit var forwardBtn: MaterialButton
    private lateinit var fullscreenBtn: MaterialButton
    private lateinit var gripView: View
    private var fsIconFull: Boolean? = null

    // ---- tool buttons
    private lateinit var queueTool: MaterialButton
    private lateinit var shuffleTool: MaterialButton
    private lateinit var repeatTool: MaterialButton
    private lateinit var bookmarkTool: MaterialButton
    private lateinit var abTool: MaterialButton
    private lateinit var saveTool: MaterialButton
    private lateinit var sleepTool: MaterialButton
    private lateinit var boostTool: MaterialButton
    private lateinit var silenceTool: MaterialButton
    private lateinit var eqTool: MaterialButton
    private lateinit var waveTool: MaterialButton

    // ---- state
    private var scrubbing = false
    private var speedIndex = 0
    private var currentTitle = ""
    private var currentArtist = ""
    private var lastArt: Bitmap? = null

    private var expanded = false      // tall window: big artwork / queue shown
    private var queueOpen = false
    private var toolsOpen = false
    private var wrapH = 0             // window height when it just wraps its content

    // restore point when leaving full screen
    private var savedX = 0
    private var savedY = 0
    private var savedW = 0
    private var savedH = 0
    private var savedExpanded = false

    // per-file data
    private var currentKey: String? = null
    private var resumeApplied = false
    private var lastSaveAt = 0L
    private var bookmarks: MutableList<Long> = ArrayList()
    private var peaks: FloatArray? = null

    // A-B loop
    private var abA = -1L
    private var abB = -1L

    // sleep timer
    private var sleepIdx = 0
    private var sleepEndAt = 0L

    // effects
    private var loud: LoudnessEnhancer? = null
    private var eq: Equalizer? = null
    private var effectsSession = 0

    private val titleCache = HashMap<Int, String>()
    private val queueAdapter = QueueAdapter()

    private val handler = Handler(Looper.getMainLooper())
    private val waveExecutor = Executors.newSingleThreadExecutor()
    private val trimExecutor = Executors.newSingleThreadExecutor()
    private var waveGen = 0

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, if (abA >= 0 && abB > abA) 100L else 300L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW)
        )
        currentTitle = getString(R.string.app_name)
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                togglePlay()
                return START_NOT_STICKY
            }
            ACTION_REWIND -> {
                player?.let { it.seekTo((it.currentPosition - SKIP_MS).coerceAtLeast(0L)) }
                return START_NOT_STICKY
            }
            ACTION_FORWARD -> {
                player?.let { seekForward(it) }
                return START_NOT_STICKY
            }
            ACTION_SHOW -> {
                if (mode == Mode.BUBBLE) leaveBubble()
                return START_NOT_STICKY
            }
        }

        val uris = if (intent != null) extractUris(intent) else emptyList()
        if (uris.isEmpty()) {
            if (overlay == null) stopSelf()
            return START_NOT_STICKY
        }
        if (overlay == null) createOverlay()
        playQueue(
            uris,
            intent?.getIntExtra(EXTRA_START, 0) ?: 0,
            intent?.getBooleanExtra(EXTRA_SHUFFLE, false) ?: false
        )
        if (mode == Mode.BUBBLE) leaveBubble()
        return START_NOT_STICKY
    }

    private fun extractUris(i: Intent): List<Uri> {
        val out = ArrayList<Uri>()
        val cd = i.clipData
        if (cd != null) {
            for (k in 0 until cd.itemCount) {
                val u = cd.getItemAt(k).uri
                if (u != null) out.add(u)
            }
        }
        if (out.isEmpty()) {
            val d = i.data
            if (d != null) out.add(d)
        }
        return out
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun vis(b: Boolean) = if (b) View.VISIBLE else View.GONE
    private fun toast(s: String) = Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ build the window

    private fun createOverlay() {
        themedCtx = DynamicColors.wrapContextIfAvailable(
            ContextThemeWrapper(this, R.style.Theme_FloatingPlayer)
        )
        val inflater = LayoutInflater.from(themedCtx)
        val view = inflater.inflate(R.layout.overlay_player, null) as ResizeFrameLayout
        overlay = view

        bindViews(view)
        buildTools(inflater)
        createPlayer()
        wireControls()
        initWindow(view)
        handler.post(ticker)
    }

    private fun bindViews(view: ResizeFrameLayout) {
        cardView = view.findViewById(R.id.card)
        contentView = view.findViewById(R.id.content)
        artView = view.findViewById(R.id.art)
        artBig = view.findViewById(R.id.art_big)
        artSmallCard = view.findViewById(R.id.art_card)
        artBigCard = view.findViewById(R.id.art_big_card)
        queueList = view.findViewById(R.id.queue_list)
        titleView = view.findViewById<TextView>(R.id.title).also { it.isSelected = true }
        artistView = view.findViewById(R.id.artist)
        seekBar = view.findViewById(R.id.seek)
        seekGroup = view.findViewById(R.id.seek_group)
        timeNow = view.findViewById(R.id.time_now)
        timeTotal = view.findViewById(R.id.time_total)
        controlsRow = view.findViewById(R.id.controls_row)
        toolsScroll = view.findViewById(R.id.tools_scroll)
        toolsBox = view.findViewById(R.id.tools)
        bottomBar = view.findViewById(R.id.bottom_bar)
        moreBtn = view.findViewById(R.id.more)
        playBtn = view.findViewById(R.id.play)
        prevBtn = view.findViewById(R.id.prev)
        nextBtn = view.findViewById(R.id.next)
        speedBtn = view.findViewById(R.id.speed)
        rewindBtn = view.findViewById(R.id.rewind)
        forwardBtn = view.findViewById(R.id.forward)
        fullscreenBtn = view.findViewById(R.id.fullscreen)
        gripView = view.findViewById(R.id.grip)
        queueList.adapter = queueAdapter
    }

    private fun addTool(
        inflater: LayoutInflater,
        @DrawableRes icon: Int,
        @StringRes label: Int,
        toggle: Boolean,
        onClick: () -> Unit
    ): MaterialButton {
        val b = inflater.inflate(R.layout.item_tool, toolsBox, false) as MaterialButton
        b.setIconResource(icon)
        b.setText(label)
        b.isCheckable = toggle
        b.setOnClickListener { onClick() }
        toolsBox.addView(b)
        return b
    }

    private fun buildTools(inflater: LayoutInflater) {
        queueTool = addTool(inflater, R.drawable.ic_queue, R.string.tool_queue, false) { toggleQueue() }
        shuffleTool = addTool(inflater, R.drawable.ic_shuffle, R.string.tool_shuffle, true) {
            player?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
            refreshTools()
        }
        repeatTool = addTool(inflater, R.drawable.ic_repeat, R.string.tool_repeat, true) { cycleRepeat() }
        bookmarkTool = addTool(inflater, R.drawable.ic_bookmark, R.string.tool_bookmark, false) { toggleBookmark() }
        bookmarkTool.setOnLongClickListener {
            jumpToNextBookmark()
            true
        }
        abTool = addTool(inflater, R.drawable.ic_repeat, R.string.tool_ab, true) { cycleAb() }
        saveTool = addTool(inflater, R.drawable.ic_content_cut, R.string.tool_save_ab, false) { saveAb() }
        sleepTool = addTool(inflater, R.drawable.ic_timer, R.string.tool_sleep, true) { cycleSleep() }
        boostTool = addTool(inflater, R.drawable.ic_volume_up, R.string.tool_boost, true) { cycleBoost() }
        silenceTool = addTool(inflater, R.drawable.ic_volume_off, R.string.tool_silence, true) { toggleSilence() }
        eqTool = addTool(inflater, R.drawable.ic_equalizer, R.string.tool_eq, true) { cycleEq() }
        waveTool = addTool(inflater, R.drawable.ic_graphic_eq, R.string.tool_wave, true) { toggleWave() }
        refreshTools()
    }

    private fun createPlayer() {
        // AMR (and some MP3/ADTS) files have no duration/seek table. Constant-bitrate seeking
        // lets the player estimate the duration and seek in them.
        val extractors = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
        val p = ExoPlayer.Builder(this, DefaultMediaSourceFactory(this, extractors))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.skipSilenceEnabled = Prefs.skipSilence(this)
        player = p
        mediaSession = MediaSession.Builder(this, p).build()
        p.addListener(playerListener)
        updateNotification()
    }

    private val playerListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                val old = currentKey
                if (old != null) ResumeStore.clearPos(this@OverlayPlayerService, old)
            }
            val uri = mediaItem?.localConfiguration?.uri
            currentTitle = if (uri != null) displayName(uri) else getString(R.string.unknown_track)
            currentArtist = ""
            titleView.text = currentTitle
            artistView.text = currentArtist
            setArt(null)
            currentKey = if (uri != null) fileKey(uri) else null
            resumeApplied = false
            abA = -1L
            abB = -1L
            seekBar.setAb(-1L, -1L)
            val k = currentKey
            bookmarks = if (k != null) ResumeStore.bookmarks(this@OverlayPlayerService, k) else ArrayList()
            seekBar.setMarkers(bookmarks)
            loadWaveform()
            refreshTools()
            queueAdapter.notifyDataSetChanged()
            updateNotification()
        }

        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
            val t = mediaMetadata.title?.toString()
            if (!t.isNullOrBlank()) {
                currentTitle = t
                titleView.text = t
            }
            val a = (mediaMetadata.artist ?: mediaMetadata.albumArtist)?.toString()
            if (!a.isNullOrBlank()) {
                currentArtist = a
                artistView.text = a
            }
            val art = mediaMetadata.artworkData
            if (art != null) setArt(art)
            updateNotification()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playBtn.setIconResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            bubbleBadge?.setImageResource(if (isPlaying) R.drawable.ic_badge_pause else R.drawable.ic_badge_play)
            seekBar.setPlaying(isPlaying)
            if (!isPlaying) saveResume()
            updateNotification()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY && !resumeApplied) {
                resumeApplied = true
                applyResume()
            }
            if (playbackState == Player.STATE_ENDED) {
                val k = currentKey
                if (k != null) ResumeStore.clearPos(this@OverlayPlayerService, k)
                if (Prefs.autoClose(this@OverlayPlayerService)) stopSelf()
            }
            updateProgress()
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM && sleepIdx == SLEEP_END) {
                sleepIdx = 0
                player?.pauseAtEndOfMediaItems = false
                toast(getString(R.string.toast_sleep_done))
                refreshTools()
            }
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            attachEffects(audioSessionId)
        }

        override fun onPlayerError(error: PlaybackException) {
            toast(getString(R.string.toast_play_error))
        }
    }

    private fun wireControls() {
        val p = player ?: return

        findViewById2(R.id.close).setOnClickListener { stopSelf() }

        playBtn.setOnClickListener { togglePlay() }
        rewindBtn.setOnClickListener {
            p.seekTo((p.currentPosition - SKIP_MS).coerceAtLeast(0L))
        }
        forwardBtn.setOnClickListener { seekForward(p) }
        fullscreenBtn.setOnClickListener {
            if (mode == Mode.FLOATING) enterFullscreen() else if (mode == Mode.FULLSCREEN) exitFullscreen()
        }
        prevBtn.setOnClickListener { p.seekToPrevious() }
        nextBtn.setOnClickListener { p.seekToNext() }

        speedIndex = Prefs.speed(this).coerceIn(0, SPEEDS.size - 1)
        p.playbackParameters = PlaybackParameters(SPEEDS[speedIndex])
        speedBtn.setOnClickListener {
            speedIndex = (speedIndex + 1) % SPEEDS.size
            Prefs.setSpeed(this, speedIndex)
            val s = SPEEDS[speedIndex]
            p.playbackParameters = PlaybackParameters(s)
            speedBtn.text = speedLabel(s)
        }
        speedBtn.text = speedLabel(SPEEDS[speedIndex])

        moreBtn.setOnClickListener {
            toolsOpen = !toolsOpen
            Prefs.setTools(this, toolsOpen)
            applyLevel()
            if (params.height == WindowManager.LayoutParams.WRAP_CONTENT) wrapH = measureWrapH(params.width)
            overlay?.post { overlay?.let { move(it, params.x, params.y) } }
        }

        queueList.setOnItemClickListener { _, _, pos, _ ->
            p.seekTo(pos, 0L)
            p.play()
        }

        // seek by touching / dragging the wavy bar
        seekBar.listener = object : WavySeekBar.Listener {
            override fun onScrubStart() {
                scrubbing = true
            }

            override fun onScrub(positionMs: Long) {
                timeNow.text = fmt(positionMs)
            }

            override fun onScrubEnd(positionMs: Long) {
                p.seekTo(positionMs)
                scrubbing = false
            }
        }
        seekBar.setBars(Prefs.wave(this))

        // double tap the big artwork: +-10 s, single tap: play / pause
        val detector = GestureDetector(themedCtx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                togglePlay()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (e.x < artBig.width / 2f) p.seekTo((p.currentPosition - SKIP_MS).coerceAtLeast(0L))
                else seekForward(p)
                return true
            }
        })
        artBig.setOnTouchListener { _, e -> detector.onTouchEvent(e) }
    }

    private fun findViewById2(id: Int): View = overlay!!.findViewById(id)

    // ------------------------------------------------------------------ window geometry

    private fun initWindow(view: ResizeFrameLayout) {
        val dm = resources.displayMetrics
        val remember = Prefs.remember(this)
        val frac = when (Prefs.size(this)) {
            0 -> 0.82f
            2 -> 0.98f
            else -> 0.92f
        }
        val width = if (remember && Prefs.hasSize(this)) {
            Prefs.sizeW(this).coerceIn(dp(MIN_W_DP), dm.widthPixels)
        } else {
            (dm.widthPixels * frac).toInt()
        }
        toolsOpen = Prefs.tools(this)

        params = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            alpha = Prefs.opacity(this@OverlayPlayerService) / 100f
        }

        applyLevel()
        wrapH = measureWrapH(width)

        val maxH = (dm.heightPixels * 0.92f).toInt()
        val savedHeight = if (remember) Prefs.sizeH(this) else 0
        if (savedHeight > 0) {
            val h = savedHeight.coerceIn(dp(MIN_H_DP), maxH)
            if (abs(h - wrapH) > dp(16)) {
                params.height = h
                setExpanded(h > wrapH)
            }
        }

        val winH = if (params.height > 0) params.height else wrapH
        if (remember && Prefs.hasPos(this)) {
            params.x = Prefs.posX(this).coerceIn(0, maxOf(0, dm.widthPixels - width))
            params.y = Prefs.posY(this).coerceIn(0, maxOf(0, dm.heightPixels - winH))
        } else {
            params.x = (dm.widthPixels - width) / 2
            params.y = (dm.heightPixels * 0.12f).toInt()
        }

        attachDrag(view.findViewById(R.id.handle), view)
        attachDrag(view.findViewById(R.id.header), view)
        attachResize(view)
        attachBottomBar()

        wm.addView(view, params)

        when (Prefs.startMode(this)) {
            1 -> view.post { enterBubble(0) }
            2 -> view.post { enterFullscreen() }
        }
    }

    private fun setContentHeights(h: Int) {
        val a = cardView.layoutParams
        a.height = h
        cardView.layoutParams = a
        val b = contentView.layoutParams
        b.height = h
        contentView.layoutParams = b
    }

    /** Tall window: show the big artwork (or the queue) above the controls. */
    private fun setExpanded(e: Boolean) {
        if (expanded != e) {
            expanded = e
            setContentHeights(if (e) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        applyLevel()
    }

    /** Height the window needs when it only wraps its content (all rows visible). */
    private fun measureWrapH(widthPx: Int): Int {
        val view = overlay ?: return dp(260)
        val keepExpanded = expanded
        val keepH = params.height
        expanded = false
        setContentHeights(ViewGroup.LayoutParams.WRAP_CONTENT)
        params.height = WindowManager.LayoutParams.WRAP_CONTENT
        applyLevel()
        view.measure(
            View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = view.measuredHeight
        params.height = keepH
        expanded = keepExpanded
        setContentHeights(if (keepExpanded) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT)
        applyLevel()
        return h
    }

    /** Show only the parts that fit in the current window size. */
    private fun applyLevel() {
        val dm = resources.displayMetrics
        val d = dm.density
        val wDp = (if (params.width > 0) params.width else dm.widthPixels) / d
        val auto = params.height == WindowManager.LayoutParams.WRAP_CONTENT
        val hDp = if (auto) 10000f else (if (params.height > 0) params.height else dm.heightPixels) / d
        val full = mode == Mode.FULLSCREEN

        artBigCard.visibility = vis(expanded)
        queueList.visibility = vis(expanded && queueOpen)
        artBig.visibility = vis(!(expanded && queueOpen))
        artSmallCard.visibility = vis(!expanded && wDp >= 200f && hDp >= 130f)
        artistView.visibility = vis(wDp >= 180f)
        moreBtn.visibility = vis(!full && wDp >= 220f && hDp >= 200f)
        seekGroup.visibility = vis(hDp >= 160f)
        controlsRow.visibility = vis(hDp >= 230f)
        rewindBtn.visibility = vis(wDp >= 200f)
        forwardBtn.visibility = vis(wDp >= 200f)
        speedBtn.visibility = vis(wDp >= 240f)
        val multi = (player?.mediaItemCount ?: 0) > 1
        prevBtn.visibility = vis(multi && wDp >= 240f)
        nextBtn.visibility = vis(multi && wDp >= 240f)
        toolsScroll.visibility = vis((toolsOpen || full) && hDp >= 300f)
        bottomBar.visibility = vis(hDp >= 130f)
        fullscreenBtn.visibility = vis(wDp >= 260f && hDp >= 200f)
        gripView.visibility = vis(!full && hDp >= 130f)
        if (fsIconFull != full) {
            fsIconFull = full
            fullscreenBtn.setIconResource(if (full) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen)
            fullscreenBtn.contentDescription =
                getString(if (full) R.string.cd_exit_fullscreen else R.string.cd_fullscreen)
        }
    }

    /** Move the window by dragging the top handle or the header. Push past a wall -> bubble. */
    private fun attachDrag(target: View, root: View) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var wall = 0
        target.setOnTouchListener { _, e ->
            if (mode != Mode.FLOATING) return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    wall = 0
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val desiredX = startX + (e.rawX - touchX).toInt()
                    val desiredY = startY + (e.rawY - touchY).toInt()
                    wall = wallSide(desiredX)
                    params.alpha = if (wall != 0) 0.5f else Prefs.opacity(this) / 100f
                    move(root, desiredX, desiredY)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    params.alpha = Prefs.opacity(this) / 100f
                    if (wall != 0 && e.actionMasked == MotionEvent.ACTION_UP) {
                        val side = wall
                        wall = 0
                        handler.post { enterBubble(side) }
                    } else {
                        savePlacement()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun wallSide(desiredX: Int): Int {
        val dm = resources.displayMetrics
        return when {
            desiredX < -dp(56) -> -1
            desiredX + params.width > dm.widthPixels + dp(56) -> 1
            else -> 0
        }
    }

    private fun move(root: View, x: Int, y: Int) {
        val dm = resources.displayMetrics
        params.x = x.coerceIn(0, maxOf(0, dm.widthPixels - params.width))
        params.y = y.coerceIn(0, maxOf(0, dm.heightPixels - root.height))
        wm.updateViewLayout(root, params)
    }

    /** Resize the window by dragging any edge or the bottom corner. */
    private fun attachResize(view: ResizeFrameLayout) {
        var startX = 0
        var startY = 0
        var startW = 0
        var startH = 0
        var touchX = 0f
        var touchY = 0f

        view.callback = object : ResizeFrameLayout.Callback {
            override fun onResizeStart(edges: Int, rawX: Float, rawY: Float) {
                startX = params.x
                startY = params.y
                startW = params.width
                startH = view.height
                touchX = rawX
                touchY = rawY
                resizeEdges = edges
            }

            override fun onResize(rawX: Float, rawY: Float) {
                val dm = resources.displayMetrics
                val dx = (rawX - touchX).toInt()
                val dy = (rawY - touchY).toInt()
                val maxH = (dm.heightPixels * 0.92f).toInt()
                val e = resizeEdges

                var w = startW
                var h = startH
                if ((e and ResizeFrameLayout.LEFT) != 0) w = startW - dx
                if ((e and ResizeFrameLayout.RIGHT) != 0) w = startW + dx
                if ((e and ResizeFrameLayout.TOP) != 0) h = startH - dy
                if ((e and ResizeFrameLayout.BOTTOM) != 0) h = startH + dy

                w = w.coerceIn(dp(MIN_W_DP), dm.widthPixels)
                h = h.coerceIn(dp(MIN_H_DP), maxH)
                val auto = abs(h - wrapH) <= dp(16)
                val heff = if (auto) wrapH else h

                var x = startX
                var y = startY
                if ((e and ResizeFrameLayout.LEFT) != 0) x = startX + startW - w
                if ((e and ResizeFrameLayout.TOP) != 0) y = startY + startH - heff

                params.width = w
                params.height = if (auto) WindowManager.LayoutParams.WRAP_CONTENT else h
                params.x = x.coerceIn(0, maxOf(0, dm.widthPixels - w))
                params.y = y.coerceIn(0, maxOf(0, dm.heightPixels - heff))
                setExpanded(!auto && h > wrapH)
                wm.updateViewLayout(view, params)
            }

            override fun onResizeEnd() {
                resizeEdges = 0
                if (params.height == WindowManager.LayoutParams.WRAP_CONTENT) wrapH = measureWrapH(params.width)
                savePlacement()
            }
        }
    }

    private var resizeEdges = 0

    /** Bottom bar: swipe up = hide (bubble) or leave full screen, swipe down = full screen. */
    private fun attachBottomBar() {
        var y0 = 0f
        var done = false
        bottomBar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    y0 = e.rawY
                    done = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!done) {
                        val dy = e.rawY - y0
                        val th = dp(48).toFloat()
                        if (dy < -th) {
                            done = true
                            handler.post { onBarUp() }
                        } else if (dy > th) {
                            done = true
                            handler.post { onBarDown() }
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
    }

    private fun onBarUp() {
        if (mode == Mode.FULLSCREEN) exitFullscreen() else if (mode == Mode.FLOATING) enterBubble(0)
    }

    private fun onBarDown() {
        if (mode == Mode.FLOATING) enterFullscreen()
    }

    private fun savePlacement() {
        if (!Prefs.remember(this) || mode != Mode.FLOATING) return
        Prefs.savePos(this, params.x, params.y)
        val h = if (params.height > 0) params.height else 0
        Prefs.saveSize(this, params.width, h)
    }

    private fun systemDimen(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    // ------------------------------------------------------------------ full screen

    private fun enterFullscreen() {
        val view = overlay ?: return
        if (mode != Mode.FLOATING) return
        savedX = params.x
        savedY = params.y
        savedW = params.width
        savedH = params.height
        savedExpanded = expanded
        mode = Mode.FULLSCREEN

        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        params.width = WindowManager.LayoutParams.MATCH_PARENT
        params.height = WindowManager.LayoutParams.MATCH_PARENT
        params.x = 0
        params.y = 0
        params.alpha = 1f
        view.setPadding(dp(8), systemDimen("status_bar_height") + dp(8), dp(8), systemDimen("navigation_bar_height") + dp(8))
        cardView.radius = dp(20).toFloat()
        view.resizeEnabled = false
        applyFullscreenSizing(true)
        setExpanded(true)
        wm.updateViewLayout(view, params)
    }

    private fun exitFullscreen() {
        val view = overlay ?: return
        if (mode != Mode.FULLSCREEN) return
        mode = Mode.FLOATING
        queueOpen = false

        val dm = resources.displayMetrics
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        params.width = savedW.coerceIn(dp(MIN_W_DP), dm.widthPixels)
        params.height = if (savedH > 0) savedH.coerceAtMost((dm.heightPixels * 0.92f).toInt()) else savedH
        val restoredH = if (params.height > 0) params.height else wrapH
        params.x = savedX.coerceIn(0, maxOf(0, dm.widthPixels - params.width))
        params.y = savedY.coerceIn(0, maxOf(0, dm.heightPixels - restoredH))
        params.alpha = Prefs.opacity(this) / 100f
        view.setPadding(dp(12), dp(12), dp(12), dp(12))
        cardView.radius = dp(28).toFloat()
        view.resizeEnabled = true
        applyFullscreenSizing(false)
        setExpanded(savedExpanded)
        wm.updateViewLayout(view, params)
        refreshTools()
    }

    private fun setViewHeight(v: View, h: Int) {
        val lp = v.layoutParams
        if (lp.height != h) {
            lp.height = h
            v.layoutParams = lp
        }
    }

    /** Bigger text, taller seek bar and bigger buttons in full screen. */
    private fun applyFullscreenSizing(full: Boolean) {
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (full) 22f else 16f)
        artistView.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (full) 16f else 14f)
        setViewHeight(seekBar, dp(if (full) 64 else 40))
        setViewHeight(playBtn, dp(if (full) 76 else 56))
        for (b in arrayOf(prevBtn, rewindBtn, forwardBtn, nextBtn)) setViewHeight(b, dp(if (full) 60 else 48))
        playBtn.iconSize = dp(if (full) 44 else 32)
    }

    /** Screen rotated: keep every window inside the new screen. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val view = overlay ?: return
        val dm = resources.displayMetrics
        try {
            when (mode) {
                Mode.FLOATING -> {
                    params.width = params.width.coerceIn(dp(MIN_W_DP), dm.widthPixels)
                    if (params.height > 0) params.height = params.height.coerceAtMost((dm.heightPixels * 0.92f).toInt())
                    wrapH = measureWrapH(params.width)
                    val h = if (params.height > 0) params.height else wrapH
                    params.x = params.x.coerceIn(0, maxOf(0, dm.widthPixels - params.width))
                    params.y = params.y.coerceIn(0, maxOf(0, dm.heightPixels - h))
                    applyLevel()
                    wm.updateViewLayout(view, params)
                }
                Mode.FULLSCREEN -> {
                    view.setPadding(
                        dp(8), systemDimen("status_bar_height") + dp(8),
                        dp(8), systemDimen("navigation_bar_height") + dp(8)
                    )
                    wm.updateViewLayout(view, params)
                }
                Mode.BUBBLE -> bubble?.let { snapBubble(it) }
            }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ bubble

    private fun enterBubble(side: Int) {
        val view = overlay ?: return
        if (mode == Mode.BUBBLE) return
        if (mode == Mode.FULLSCREEN) exitFullscreen()
        val dm = resources.displayMetrics
        val left = when (side) {
            -1 -> true
            1 -> false
            else -> params.x + params.width / 2 < dm.widthPixels / 2
        }
        val h = if (params.height > 0) params.height else view.height
        val centerY = params.y + h / 2
        savePlacement()
        try {
            wm.removeView(view)
        } catch (_: Exception) {
        }
        mode = Mode.BUBBLE
        showBubble(left, centerY - dp(32))
    }

    private fun showBubble(left: Boolean, yPos: Int) {
        val dm = resources.displayMetrics
        val size = dp(64)
        var b = bubble
        if (b == null) {
            b = LayoutInflater.from(themedCtx).inflate(R.layout.bubble, null)
            bubble = b
            bubbleArt = b.findViewById(R.id.bubble_art)
            bubbleBadge = b.findViewById(R.id.bubble_badge)
            bubbleRing = b.findViewById(R.id.bubble_ring)
            attachBubbleTouch(b)
        }
        bubbleParams = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (left) 0 else dm.widthPixels - size
            y = yPos.coerceIn(0, maxOf(0, dm.heightPixels - size))
        }
        updateBubbleArt()
        val playing = player?.isPlaying == true
        bubbleBadge?.setImageResource(if (playing) R.drawable.ic_badge_pause else R.drawable.ic_badge_play)
        try {
            wm.addView(b, bubbleParams)
        } catch (_: Exception) {
        }
    }

    private fun updateBubbleArt() {
        val iv = bubbleArt ?: return
        val art = lastArt
        if (art != null) {
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(art)
        } else {
            iv.scaleType = ImageView.ScaleType.CENTER
            iv.setImageResource(R.drawable.ic_music_note)
        }
    }

    /** Tap the bubble: open the window. Long press: play / pause. Drag: move and snap to a side. */
    private fun attachBubbleTouch(b: View) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var longFired = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val longPress = Runnable {
            longFired = true
            togglePlay()
        }
        b.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = bubbleParams.x
                    startY = bubbleParams.y
                    moved = false
                    longFired = false
                    handler.postDelayed(longPress, 600L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                    if (moved) {
                        val dm = resources.displayMetrics
                        val size = dp(64)
                        bubbleParams.x = (startX + dx).toInt().coerceIn(0, maxOf(0, dm.widthPixels - size))
                        bubbleParams.y = (startY + dy).toInt().coerceIn(0, maxOf(0, dm.heightPixels - size))
                        wm.updateViewLayout(b, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (moved) snapBubble(b) else if (!longFired) leaveBubble()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    true
                }
                else -> false
            }
        }
    }

    private fun snapBubble(b: View) {
        val dm = resources.displayMetrics
        val size = dp(64)
        bubbleParams.x = if (bubbleParams.x + size / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - size
        bubbleParams.y = bubbleParams.y.coerceIn(0, maxOf(0, dm.heightPixels - size))
        wm.updateViewLayout(b, bubbleParams)
    }

    private fun leaveBubble() {
        val view = overlay ?: return
        if (mode != Mode.BUBBLE) return
        val dm = resources.displayMetrics
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        mode = Mode.FLOATING
        val h = if (params.height > 0) params.height else wrapH
        val left = bubbleParams.x < dm.widthPixels / 2
        val x = if (left) dp(8) else dm.widthPixels - params.width - dp(8)
        params.x = x.coerceIn(0, maxOf(0, dm.widthPixels - params.width))
        params.y = (bubbleParams.y + dp(32) - h / 2).coerceIn(0, maxOf(0, dm.heightPixels - h))
        params.alpha = Prefs.opacity(this) / 100f
        try {
            wm.addView(view, params)
        } catch (_: Exception) {
        }
        applyLevel()
        savePlacement()
    }

    // ------------------------------------------------------------------ playback

    private fun togglePlay() {
        val p = player ?: return
        when {
            p.playbackState == Player.STATE_ENDED -> {
                p.seekTo(0, 0L)
                p.play()
            }
            p.isPlaying -> p.pause()
            else -> p.play()
        }
    }

    private fun seekForward(p: Player) {
        val d = p.duration
        val t = p.currentPosition + SKIP_MS
        p.seekTo(if (d != C.TIME_UNSET) minOf(t, d) else t)
    }

    private fun playQueue(uris: List<Uri>, start: Int, shuffle: Boolean) {
        val p = player ?: return
        titleCache.clear()
        p.setMediaItems(uris.map { MediaItem.fromUri(it) }, start.coerceIn(0, uris.size - 1), C.TIME_UNSET)
        if (shuffle) p.shuffleModeEnabled = true
        p.prepare()
        p.play()
        attachEffects(p.audioSessionId)
        queueAdapter.notifyDataSetChanged()
        applyLevel()
        refreshTools()
    }

    private fun updateProgress() {
        val p = player ?: return
        val dur = if (p.duration == C.TIME_UNSET || p.duration < 0) 0L else p.duration
        val known = dur > 0
        val pos = if (known) p.currentPosition.coerceIn(0L, dur) else maxOf(p.currentPosition, 0L)

        // A-B loop
        if (abA >= 0 && abB > abA && pos >= abB && p.isPlaying) p.seekTo(abA)

        seekBar.setProgress(pos, dur)
        if (!scrubbing) timeNow.text = fmt(pos)
        timeTotal.text = if (known) fmt(dur) else "--:--"

        if (mode == Mode.BUBBLE && known) {
            bubbleRing?.setProgressCompat(((pos * 1000) / dur).toInt(), false)
        }

        // sleep timer
        if (sleepEndAt > 0L) {
            if (System.currentTimeMillis() >= sleepEndAt) {
                sleepEndAt = 0L
                sleepIdx = 0
                p.pause()
                toast(getString(R.string.toast_sleep_done))
            }
            refreshTools()
        }

        // remember the position
        if (p.isPlaying && System.currentTimeMillis() - lastSaveAt > 5000L) saveResume()
    }

    private fun saveResume() {
        if (!Prefs.resume(this)) return
        val p = player ?: return
        val k = currentKey ?: return
        if (!resumeApplied) return
        val pos = p.currentPosition
        val dur = p.duration
        lastSaveAt = System.currentTimeMillis()
        if (dur != C.TIME_UNSET && dur > 0 && pos > dur - 3000L) ResumeStore.clearPos(this, k)
        else if (pos > 3000L) ResumeStore.setPos(this, k, pos)
        else ResumeStore.clearPos(this, k)
    }

    private fun applyResume() {
        if (!Prefs.resume(this)) return
        val p = player ?: return
        val k = currentKey ?: return
        val saved = ResumeStore.getPos(this, k)
        val dur = p.duration
        if (saved > 3000L && (dur == C.TIME_UNSET || saved < dur - 3000L)) {
            p.seekTo(saved)
            toast(getString(R.string.toast_resumed, fmt(saved)))
        }
    }

    private fun setArt(data: ByteArray?) {
        val bmp: Bitmap? = if (data == null) null else try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 640 && bounds.outHeight / (sample * 2) >= 640) sample *= 2
            BitmapFactory.decodeByteArray(data, 0, data.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Exception) {
            null
        }
        lastArt = bmp
        bindArt(artView, bmp, false)
        bindArt(artBig, bmp, true)
        updateBubbleArt()
    }

    private fun bindArt(iv: ImageView, bmp: Bitmap?, big: Boolean) {
        if (bmp != null) {
            iv.setPadding(0, 0, 0, 0)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(bmp)
        } else {
            val pad = if (big) dp(56) else 0
            iv.setPadding(pad, pad, pad, pad)
            iv.scaleType = if (big) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER
            iv.setImageResource(R.drawable.ic_music_note)
        }
    }

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c ->
                        if (c.moveToFirst()) {
                            val n = c.getString(0)
                            if (!n.isNullOrBlank()) return n
                        }
                    }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: getString(R.string.unknown_track)
    }

    /** Stable id of a file (name + size) so positions and bookmarks survive a new URI. */
    private fun fileKey(uri: Uri): String {
        var name: String? = null
        var size = -1L
        if (uri.scheme == "content") {
            try {
                contentResolver.query(
                    uri,
                    arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                    null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) {
                        name = c.getString(0)
                        size = c.getLong(1)
                    }
                }
            } catch (_: Exception) {
            }
        } else if (uri.scheme == "file") {
            val f = File(uri.path ?: "")
            name = f.name
            size = f.length()
        }
        return ResumeStore.key(name ?: uri.toString(), size)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private fun speedLabel(s: Float): String =
        (if (s == s.toInt().toFloat()) s.toInt().toString() else s.toString()) + "×"

    // ------------------------------------------------------------------ tools

    private fun scrollQueue() {
        queueAdapter.notifyDataSetChanged()
        queueList.setSelection(player?.currentMediaItemIndex ?: 0)
    }

    private fun toggleQueue() {
        if (mode == Mode.BUBBLE) return
        if (!expanded) {
            queueOpen = true
            if (mode == Mode.FLOATING) enterFullscreen() else setExpanded(true)
        } else {
            queueOpen = !queueOpen
            applyLevel()
        }
        scrollQueue()
        refreshTools()
    }

    private fun cycleRepeat() {
        val p = player ?: return
        p.repeatMode = when (p.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        refreshTools()
    }

    private fun toggleBookmark() {
        val p = player ?: return
        val k = currentKey ?: return
        val pos = p.currentPosition
        val near = bookmarks.firstOrNull { abs(it - pos) < 3000L }
        if (near != null) {
            bookmarks.remove(near)
            toast(getString(R.string.toast_bookmark_removed))
        } else {
            bookmarks.add(pos)
            bookmarks.sort()
            toast(getString(R.string.toast_bookmark_added, fmt(pos)))
        }
        ResumeStore.saveBookmarks(this, k, bookmarks)
        seekBar.setMarkers(bookmarks)
    }

    private fun jumpToNextBookmark() {
        val p = player ?: return
        if (bookmarks.isEmpty()) {
            toast(getString(R.string.toast_no_bookmarks))
            return
        }
        val pos = p.currentPosition
        val next = bookmarks.firstOrNull { it > pos + 1000L } ?: bookmarks[0]
        p.seekTo(next)
    }

    /** First tap: point A. Second tap: point B and loop. Third tap: clear. */
    private fun cycleAb() {
        val p = player ?: return
        val pos = p.currentPosition
        when {
            abA < 0 -> {
                abA = pos
                toast(getString(R.string.toast_ab_a, fmt(pos)))
            }
            abB < 0 -> {
                if (pos > abA + 500L) {
                    abB = pos
                    p.seekTo(abA)
                } else {
                    abA = -1L
                }
            }
            else -> {
                abA = -1L
                abB = -1L
            }
        }
        seekBar.setAb(abA, abB)
        refreshTools()
    }

    /** Cut the A-B part out of the file and save it to Music/FloatingPlayer. */
    private fun saveAb() {
        val p = player ?: return
        val uri = p.currentMediaItem?.localConfiguration?.uri ?: return
        if (abA < 0 || abB <= abA) return
        val a = abA
        val b = abB
        val base = currentTitle.substringBeforeLast('.') + "_" +
            fmt(a).replace(':', '-') + "_" + fmt(b).replace(':', '-')
        toast(getString(R.string.toast_saving))
        trimExecutor.execute {
            val res = AudioTrimmer.trim(applicationContext, uri, a, b, base)
            handler.post {
                toast(if (res != null) getString(R.string.toast_saved, res) else getString(R.string.toast_save_failed))
            }
        }
    }

    private fun cycleSleep() {
        val p = player ?: return
        sleepIdx = (sleepIdx + 1) % (SLEEP_MIN.size + 2)
        sleepEndAt = 0L
        p.pauseAtEndOfMediaItems = false
        if (sleepIdx == SLEEP_END) {
            p.pauseAtEndOfMediaItems = true
        } else if (sleepIdx > 0) {
            sleepEndAt = System.currentTimeMillis() + SLEEP_MIN[sleepIdx - 1] * 60_000L
        }
        refreshTools()
    }

    private fun cycleBoost() {
        Prefs.setBoost(this, (Prefs.boost(this) + 1) % BOOST_STEPS)
        applyBoost()
        refreshTools()
    }

    private fun toggleSilence() {
        val on = !Prefs.skipSilence(this)
        Prefs.setSkipSilence(this, on)
        player?.skipSilenceEnabled = on
        refreshTools()
    }

    private fun cycleEq() {
        val e = eq
        if (e == null) {
            toast(getString(R.string.toast_eq_unsupported))
            refreshTools()
            return
        }
        val n = e.numberOfPresets.toInt()
        Prefs.setEq(this, (Prefs.eq(this) + 1) % (n + 2))
        applyEq()
        refreshTools()
    }

    private fun toggleWave() {
        val on = !Prefs.wave(this)
        Prefs.setWave(this, on)
        seekBar.setBars(on)
        if (on) loadWaveform() else seekBar.setPeaks(null)
        refreshTools()
    }

    /** Decode the file in the background and draw its waveform. */
    private fun loadWaveform() {
        val p = player ?: return
        waveGen++
        peaks = null
        seekBar.setPeaks(null)
        if (!Prefs.wave(this)) return
        val uri = p.currentMediaItem?.localConfiguration?.uri ?: return
        val gen = waveGen
        waveExecutor.execute {
            val result = WaveformExtractor.extract(applicationContext, uri, 200) { gen != waveGen }
            handler.post {
                if (gen == waveGen && result != null) {
                    peaks = result
                    seekBar.setPeaks(result)
                }
            }
        }
    }

    // ------------------------------------------------------------------ audio effects

    private fun attachEffects(session: Int) {
        if (session == 0 || session == effectsSession) return
        releaseEffects()
        effectsSession = session
        loud = try {
            LoudnessEnhancer(session)
        } catch (_: Exception) {
            null
        }
        eq = try {
            Equalizer(0, session)
        } catch (_: Exception) {
            null
        }
        applyBoost()
        applyEq()
        refreshTools()
    }

    private fun releaseEffects() {
        try {
            loud?.release()
        } catch (_: Exception) {
        }
        try {
            eq?.release()
        } catch (_: Exception) {
        }
        loud = null
        eq = null
        effectsSession = 0
    }

    private fun applyBoost() {
        val step = Prefs.boost(this)
        try {
            loud?.setTargetGain(step * 300)
            loud?.setEnabled(step > 0)
        } catch (_: Exception) {
        }
    }

    private fun applyEq() {
        val e = eq ?: return
        val idx = Prefs.eq(this)
        try {
            if (idx == 0) {
                e.setEnabled(false)
                return
            }
            e.setEnabled(true)
            val n = e.numberOfPresets.toInt()
            if (idx <= n) {
                e.usePreset((idx - 1).toShort())
            } else {
                // "Voice": lift the speech range, trim the lows
                val range = e.bandLevelRange
                val lo = range[0].toInt()
                val hi = range[1].toInt()
                for (b in 0 until e.numberOfBands.toInt()) {
                    val f = e.getCenterFreq(b.toShort())
                    val lvl = when {
                        f in 300_000..4_000_000 -> (hi * 0.7f).toInt()
                        f < 150_000 -> (lo * 0.6f).toInt()
                        else -> 0
                    }
                    e.setBandLevel(b.toShort(), lvl.toShort())
                }
            }
        } catch (_: Exception) {
        }
    }

    /** Sync the labels and checked states of the tool buttons with the real state. */
    private fun refreshTools() {
        val p = player

        queueTool.isChecked = expanded && queueOpen
        shuffleTool.isChecked = p?.shuffleModeEnabled == true

        val rm = p?.repeatMode ?: Player.REPEAT_MODE_OFF
        repeatTool.isChecked = rm != Player.REPEAT_MODE_OFF
        repeatTool.setIconResource(if (rm == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        repeatTool.setText(
            when (rm) {
                Player.REPEAT_MODE_ONE -> R.string.tool_repeat_one
                Player.REPEAT_MODE_ALL -> R.string.tool_repeat_all
                else -> R.string.tool_repeat
            }
        )

        abTool.isChecked = abA >= 0
        abTool.text = when {
            abA < 0 -> getString(R.string.tool_ab)
            abB <= abA -> "A " + fmt(abA)
            else -> fmt(abA) + "–" + fmt(abB)
        }
        saveTool.visibility = vis(abA >= 0 && abB > abA)

        sleepTool.isChecked = sleepIdx != 0
        sleepTool.text = when {
            sleepIdx == 0 -> getString(R.string.tool_sleep)
            sleepIdx == SLEEP_END -> getString(R.string.tool_sleep_end)
            else -> {
                val left = ((sleepEndAt - System.currentTimeMillis()) / 60_000L + 1L).coerceAtLeast(1L)
                "$left m"
            }
        }

        val boost = Prefs.boost(this)
        boostTool.isChecked = boost > 0
        boostTool.text = if (boost == 0) getString(R.string.tool_boost) else "+" + (boost * 3) + " dB"

        silenceTool.isChecked = Prefs.skipSilence(this)

        val eqIdx = Prefs.eq(this)
        eqTool.isChecked = eqIdx > 0
        var eqText = getString(R.string.tool_eq)
        val e = eq
        if (eqIdx > 0 && e != null) {
            try {
                val n = e.numberOfPresets.toInt()
                eqText = if (eqIdx <= n) e.getPresetName((eqIdx - 1).toShort()) else getString(R.string.tool_eq_voice)
            } catch (_: Exception) {
            }
        }
        eqTool.text = eqText

        waveTool.isChecked = Prefs.wave(this)
    }

    // ------------------------------------------------------------------ queue list

    private fun titleFor(i: Int): String {
        val cached = titleCache[i]
        if (cached != null) return cached
        val uri = player?.getMediaItemAt(i)?.localConfiguration?.uri
        val name = if (uri != null) displayName(uri) else ""
        titleCache[i] = name
        return name
    }

    private inner class QueueAdapter : BaseAdapter() {
        override fun getCount(): Int = player?.mediaItemCount ?: 0
        override fun getItem(position: Int): Any = position
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val tv = (convertView ?: LayoutInflater.from(themedCtx).inflate(R.layout.item_queue, parent, false)) as TextView
            val current = position == player?.currentMediaItemIndex
            tv.text = (if (current) "▶  " else "") + (position + 1) + ". " + titleFor(position)
            tv.setTypeface(null, if (current) Typeface.BOLD else Typeface.NORMAL)
            return tv
        }
    }

    // ------------------------------------------------------------------ notification

    private fun buildNotification(): Notification {
        val playing = player?.isPlaying == true
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        fun svc(code: Int, action: String): PendingIntent =
            PendingIntent.getService(
                this, code, Intent(this, OverlayPlayerService::class.java).setAction(action), flags
            )

        val open = svc(3, ACTION_SHOW)

        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_player)
            .setContentTitle(currentTitle)
            .setContentText(currentArtist.ifBlank { getString(R.string.notif_playing) })
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(R.drawable.ic_fast_rewind, getString(R.string.cd_rewind), svc(4, ACTION_REWIND))
            .addAction(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play,
                getString(if (playing) R.string.action_pause else R.string.action_play),
                svc(1, ACTION_TOGGLE)
            )
            .addAction(R.drawable.ic_fast_forward, getString(R.string.cd_forward), svc(5, ACTION_FORWARD))
            .addAction(R.drawable.ic_close, getString(R.string.action_stop), svc(2, ACTION_STOP))

        val sess = mediaSession
        if (sess != null) {
            b.setStyle(MediaStyleNotificationHelper.MediaStyle(sess).setShowActionsInCompactView(0, 1, 2))
        }
        return b.build()
    }

    private fun updateNotification() {
        nm.notify(NOTIF_ID, buildNotification())
    }

    override fun onDestroy() {
        saveResume()
        handler.removeCallbacksAndMessages(null)
        waveGen++
        waveExecutor.shutdownNow()
        trimExecutor.shutdown()
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null
        bubble = null
        releaseEffects()
        mediaSession?.release()
        mediaSession = null
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "floating_player"
        private const val NOTIF_ID = 1
        private const val ACTION_STOP = "com.example.floatingplayer.STOP"
        private const val ACTION_TOGGLE = "com.example.floatingplayer.TOGGLE"
        private const val ACTION_REWIND = "com.example.floatingplayer.REWIND"
        private const val ACTION_FORWARD = "com.example.floatingplayer.FORWARD"
        private const val ACTION_SHOW = "com.example.floatingplayer.SHOW"
        private const val EXTRA_START = "start_index"
        private const val EXTRA_SHUFFLE = "shuffle"
        private const val SKIP_MS = 10_000L
        private const val MIN_W_DP = 120
        private const val MIN_H_DP = 100
        private const val BOOST_STEPS = 5
        private val SLEEP_MIN = longArrayOf(15L, 30L, 45L, 60L)
        private val SLEEP_END = SLEEP_MIN.size + 1
        private val SPEEDS = floatArrayOf(1f, 1.25f, 1.5f, 2f, 0.75f)

        /** Start (or update) the floating player with one or more audio files. */
        fun start(ctx: Context, uris: List<Uri>, startIndex: Int = 0, shuffle: Boolean = false) {
            val i = Intent(ctx, OverlayPlayerService::class.java)
            val clip = ClipData.newRawUri("audio", uris.first())
            for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
            i.clipData = clip
            i.putExtra(EXTRA_START, startIndex)
            i.putExtra(EXTRA_SHUFFLE, shuffle)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ContextCompat.startForegroundService(ctx, i)
        }
    }
}
