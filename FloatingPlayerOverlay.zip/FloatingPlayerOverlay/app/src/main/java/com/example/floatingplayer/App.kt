package com.example.floatingplayer

import android.app.Application
import com.google.android.material.color.DynamicColors

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Material You: use the wallpaper colors on Android 12+
        DynamicColors.applyToActivitiesIfAvailable(this)
    }
}
