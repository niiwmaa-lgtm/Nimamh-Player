package com.example.floatingplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

/** Lists the audio files of a chosen folder and plays them as a queue. */
class PlaylistActivity : AppCompatActivity() {

    private val uris = ArrayList<Uri>()
    private val names = ArrayList<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_playlist)

        val treeStr = intent.getStringExtra(EXTRA_TREE)
        if (treeStr == null) {
            finish()
            return
        }
        val tree = Uri.parse(treeStr)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }
        val list = findViewById<ListView>(R.id.list)
        val empty = findViewById<TextView>(R.id.empty)

        adapter = ArrayAdapter(this, R.layout.item_queue, R.id.queue_text, names)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> play(pos, false) }
        findViewById<MaterialButton>(R.id.btn_play_all).setOnClickListener { play(0, false) }
        findViewById<MaterialButton>(R.id.btn_shuffle).setOnClickListener { play(0, true) }

        Thread {
            val root = DocumentFile.fromTreeUri(this, tree)
            val children = root?.listFiles() ?: emptyArray()
            val files = children
                .filter { it.isFile && isAudio(it) }
                .sortedBy { (it.name ?: "").lowercase() }
            runOnUiThread {
                toolbar.title = root?.name ?: getString(R.string.playlist_title)
                uris.clear()
                names.clear()
                for (f in files) {
                    uris.add(f.uri)
                    names.add(f.name ?: "")
                }
                adapter.notifyDataSetChanged()
                empty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun isAudio(f: DocumentFile): Boolean {
        val t = f.type
        if (t != null && t.startsWith("audio/")) return true
        val n = (f.name ?: return false).lowercase()
        return AUDIO_EXT.any { n.endsWith(".$it") }
    }

    private fun play(start: Int, shuffle: Boolean) {
        if (uris.isEmpty()) return
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.toast_need_overlay, Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            return
        }
        OverlayPlayerService.start(this, ArrayList(uris), start, shuffle)
    }

    companion object {
        const val EXTRA_TREE = "tree"
        private val AUDIO_EXT = listOf(
            "amr", "awb", "m4a", "m4b", "mp3", "mp2", "ogg", "oga", "opus",
            "wav", "aac", "flac", "mka", "wma"
        )
    }
}
