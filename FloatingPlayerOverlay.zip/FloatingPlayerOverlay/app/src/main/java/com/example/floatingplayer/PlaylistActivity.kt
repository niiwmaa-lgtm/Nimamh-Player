package com.example.floatingplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

/** Lists the audio files of a chosen folder and plays them as a queue. */
class PlaylistActivity : AppCompatActivity() {

    private val uris = ArrayList<Uri>()
    private val names = ArrayList<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_playlist)

        val treeStr = intent.getStringExtra(EXTRA_TREE)
        if (treeStr == null) {
            finish()
            return
        }
        val tree = Uri.parse(treeStr)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }
        val list = findViewById<ListView>(R.id.list)
        val empty = findViewById<TextView>(R.id.empty)

        adapter = ArrayAdapter(this, R.layout.item_queue, R.id.queue_text, names)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> play(pos, false) }
        findViewById<MaterialButton>(R.id.btn_play_all).setOnClickListener { play(0, false) }
        findViewById<MaterialButton>(R.id.btn_shuffle).setOnClickListener { play(0, true) }

        Thread {
            var root: DocumentFile? = null
            var files: List<DocumentFile> = emptyList()
            try {
                root = DocumentFile.fromTreeUri(this, tree)
                val children = root?.listFiles() ?: emptyArray()
                files = children
                    .filter { it.isFile && isAudio(it) }
                    .sortedWith { a, b -> naturalCompare((a.name ?: "").lowercase(), (b.name ?: "").lowercase()) }
            } catch (_: Exception) {
                // folder gone or permission revoked: show the "empty" message
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                toolbar.title = root?.name ?: getString(R.string.playlist_title)
                uris.clear()
                names.clear()
                for (f in files) {
                    uris.add(f.uri)
                    names.add(f.name ?: "")
                }
                adapter.notifyDataSetChanged()
                empty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    /** "track2" sorts before "track10". */
    private fun naturalCompare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ei = i
                while (ei < a.length && a[ei].isDigit()) ei++
                var ej = j
                while (ej < b.length && b[ej].isDigit()) ej++
                val na = a.substring(i, ei).trimStart('0')
                val nb = b.substring(j, ej).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = ei
                j = ej
            } else {
                if (ca != cb) return ca.compareTo(cb)
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }

    private fun isAudio(f: DocumentFile): Boolean {
        val t = f.type
        if (t != null && t.startsWith("audio/")) return true
        val n = (f.name ?: return false).lowercase()
        return AUDIO_EXT.any { n.endsWith(".$it") }
    }

    private fun play(start: Int, shuffle: Boolean) {
        if (uris.isEmpty()) return
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.toast_need_overlay, Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            return
        }
        OverlayPlayerService.start(this, ArrayList(uris), start, shuffle)
    }

    companion object {
        const val EXTRA_TREE = "tree"
        private val AUDIO_EXT = listOf(
            "amr", "awb", "m4a", "m4b", "mp3", "mp2", "ogg", "oga", "opus",
            "wav", "aac", "flac", "mka", "wma"
        )
    }
}
