package com.example.floatingplayer

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.slider.Slider
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private class Row(val root: View, val status: ImageView, val action: MaterialButton)

    private lateinit var rows: LinearLayout
    private lateinit var overlayRow: Row
    private lateinit var notifRow: Row
    private lateinit var batteryRow: Row

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            for (u in uris) {
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
            }
            startPlayback(uris)
        }
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            Prefs.setLastFolder(this, uri.toString())
            openFolder(uri.toString())
        }
    }

    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rows = findViewById(R.id.rows)

        overlayRow = addRow(R.string.perm_overlay_title, R.string.perm_overlay_desc, R.string.btn_grant) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        notifRow = addRow(R.string.perm_notif_title, R.string.perm_notif_desc, R.string.btn_grant) {
            if (Build.VERSION.SDK_INT >= 33) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        batteryRow = addRow(R.string.perm_battery_title, R.string.perm_battery_desc, R.string.btn_settings) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: ActivityNotFoundException) {
            }
        }
        val defaultRow = addRow(R.string.perm_default_title, R.string.perm_default_desc, R.string.btn_settings) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (_: ActivityNotFoundException) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        defaultRow.status.setImageResource(R.drawable.ic_info)

        findViewById<MaterialButton>(R.id.btn_choose).setOnClickListener {
            pickAudio.launch(arrayOf("audio/*"))
        }
        findViewById<MaterialButton>(R.id.btn_folder).setOnClickListener {
            pickFolder.launch(null)
        }
        findViewById<MaterialButton>(R.id.btn_last_folder).setOnClickListener {
            val f = Prefs.lastFolder(this)
            if (f != null) openFolder(f)
        }

        bindSettings()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        findViewById<MaterialButton>(R.id.btn_last_folder).visibility =
            if (Prefs.lastFolder(this) != null) View.VISIBLE else View.GONE
    }

    private fun openFolder(tree: String) {
        startActivity(Intent(this, PlaylistActivity::class.java).putExtra(PlaylistActivity.EXTRA_TREE, tree))
    }

    private fun addRow(
        @StringRes title: Int,
        @StringRes desc: Int,
        @StringRes actionText: Int,
        onClick: () -> Unit
    ): Row {
        val v = layoutInflater.inflate(R.layout.item_setup, rows, false)
        v.findViewById<TextView>(R.id.row_title).setText(title)
        v.findViewById<TextView>(R.id.row_desc).setText(desc)
        val btn = v.findViewById<MaterialButton>(R.id.row_action)
        btn.setText(actionText)
        btn.setOnClickListener { onClick() }
        rows.addView(v)
        return Row(v, v.findViewById(R.id.row_status), btn)
    }

    private fun setDone(row: Row, done: Boolean) {
        row.status.setImageResource(if (done) R.drawable.ic_check_circle else R.drawable.ic_radio_unchecked)
        row.action.visibility = if (done) View.GONE else View.VISIBLE
    }

    private fun refresh() {
        setDone(overlayRow, Settings.canDrawOverlays(this))

        if (Build.VERSION.SDK_INT >= 33) {
            val ok = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            setDone(notifRow, ok)
        } else {
            notifRow.root.visibility = View.GONE
        }

        val pm = getSystemService(PowerManager::class.java)
        setDone(batteryRow, pm.isIgnoringBatteryOptimizations(packageName))
    }

    private fun startPlayback(uris: List<Uri>) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.toast_need_overlay, Toast.LENGTH_LONG).show()
            return
        }
        OverlayPlayerService.start(this, uris)
    }

    private fun bindSettings() {
        val sizeGroup = findViewById<MaterialButtonToggleGroup>(R.id.size_group)
        sizeGroup.check(
            when (Prefs.size(this)) {
                0 -> R.id.size_compact
                2 -> R.id.size_wide
                else -> R.id.size_normal
            }
        )
        sizeGroup.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                val v = when (id) {
                    R.id.size_compact -> 0
                    R.id.size_wide -> 2
                    else -> 1
                }
                Prefs.setSize(this, v)
            }
        }

        val opacity = findViewById<Slider>(R.id.opacity_slider)
        opacity.value = Prefs.opacity(this).toFloat().coerceIn(50f, 100f)
        opacity.setLabelFormatter { v -> "${v.toInt()}%" }
        opacity.addOnChangeListener { _, v, fromUser ->
            if (fromUser) Prefs.setOpacity(this, v.toInt())
        }

        val resume = findViewById<MaterialSwitch>(R.id.sw_resume)
        resume.isChecked = Prefs.resume(this)
        resume.setOnCheckedChangeListener { _, c -> Prefs.setResume(this, c) }

        val autoClose = findViewById<MaterialSwitch>(R.id.sw_autoclose)
        autoClose.isChecked = Prefs.autoClose(this)
        autoClose.setOnCheckedChangeListener { _, c -> Prefs.setAutoClose(this, c) }

        val remember = findViewById<MaterialSwitch>(R.id.sw_remember)
        remember.isChecked = Prefs.remember(this)
        remember.setOnCheckedChangeListener { _, c -> Prefs.setRemember(this, c) }
    }
}
