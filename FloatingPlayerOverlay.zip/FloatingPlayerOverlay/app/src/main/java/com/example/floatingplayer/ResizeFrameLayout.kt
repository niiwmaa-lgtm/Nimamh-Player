package com.example.floatingplayer

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.widget.FrameLayout

/**
 * Root of the floating window. A touch that starts near an edge (or on the bottom corner)
 * is taken over and reported as a resize gesture.
 */
class ResizeFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    interface Callback {
        fun onResizeStart(edges: Int, rawX: Float, rawY: Float)
        fun onResize(rawX: Float, rawY: Float)
        fun onResizeEnd()
    }

    var callback: Callback? = null
    var resizeEnabled = true

    private val d = resources.displayMetrics.density
    private val edge = 18 * d
    private val topEdge = 14 * d
    private val bottomEdge = 14 * d
    private val corner = 28 * d
    private var edges = 0

    private fun edgesAt(x: Float, y: Float): Int {
        if (x > width - corner && y > height - corner) return RIGHT or BOTTOM
        var e = 0
        if (x < edge) e = e or LEFT
        if (x > width - edge) e = e or RIGHT
        if (y < topEdge) e = e or TOP
        if (y > height - bottomEdge) e = e or BOTTOM
        return e
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (resizeEnabled && ev.actionMasked == MotionEvent.ACTION_DOWN) {
            edges = edgesAt(ev.x, ev.y)
            if (edges != 0) {
                parent?.requestDisallowInterceptTouchEvent(true)
                callback?.onResizeStart(edges, ev.rawX, ev.rawY)
                return true
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (edges == 0) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> callback?.onResize(ev.rawX, ev.rawY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                callback?.onResizeEnd()
                edges = 0
            }
        }
        return true
    }

    companion object {
        const val LEFT = 1
        const val TOP = 2
        const val RIGHT = 4
        const val BOTTOM = 8
    }
}
