# Floating Player (Overlay)

1. Create a new GitHub repo and upload everything in this folder (keep the .github folder).
2. Actions tab -> "Build APK" -> Run workflow.
3. When it finishes, download the artifact "FloatingPlayer-debug-apk" (zip containing app-debug.apk) and install it.
4. Open the app once and grant "Display over other apps" (and notifications).
5. Open any audio file and choose Floating Player as the default.
