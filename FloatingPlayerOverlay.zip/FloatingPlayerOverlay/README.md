# Floating Player 1.1 (Material 3)

Build: upload FloatingPlayerOverlay.zip to the GitHub repo (replace the old one) -> Actions builds app-debug.apk automatically.
The APK is signed with the committed app/debug.keystore, so later builds install over this one.
