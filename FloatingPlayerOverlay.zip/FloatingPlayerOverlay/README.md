# Floating Player 2.0

Upload FloatingPlayerOverlay.zip to the GitHub repo (replace the old one). The workflow in
.github/workflows/build.yml (edit it once in the repo, see build.yml here) builds the APK and
publishes it as a release. Direct link (always the latest build):

  https://github.com/<user>/<repo>/releases/latest/download/FloatingPlayer.apk

Minimum Android: 10 (API 29).
